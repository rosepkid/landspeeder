/*
 *  models.cpp
 *  
 *
 *  Created by rose marshack on Thu Jun 12 2003.
 *
 */ 
 
#include "arPrecompiled.h"
#include "stdio.h"
#include "stdlib.h" // just for random number generator

#include "arMasterSlaveFramework.h"
//#include "arTexture.h"

#include "math.h"
#include "arMath.h"

// for reading in a file

#pragma warning(disable : 4786) //For VC++ compiler
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
 
#include "landspeeder.h"

#define bldTop 30 
#define bldBottom -5 
#define AgusBottom -5
#define AgusFront 5
#define AgusBack -5 

#define AgusOutside 7.5
#define AgusInside 2.5

void letterbox(string c, float x, float y, float z);
void letterbox1(string c, float x, float y, float z);

int   height_field[AREA_SIZE][AREA_SIZE];
int     step = 1;      // number of grid squares rendered as one square

extern char timeOfDay ;
extern int LIGHTMAP ;

//extern char randomArray[MAX_COLUMNS][MAX_ROWS];
extern RandomPod** randomArray;
extern int*** whatDataBasePtr ;

extern arTexture alphaTexture[36];
extern arTexture numberTexture[10];
extern arTexture cloudsTexture;

extern arTexture *myHouseTexture ;
extern arTexture *myTreeTexture ;
extern arTexture *myBldTexture ;
extern arTexture *mySkyTop ;
extern arTexture *mySkySide ;
extern arTexture *myGrass ;
extern double* RoadArray;
extern int number_of_road_nodes ;

extern int num_cols; // 4000!!!!!
extern int num_rows;
extern int rows_to_display ;
extern int cols_to_display ;
extern GLuint startList ;

void makeHouse (char c) ;
void makeBigHouse (char c) ;
void makeLowCloudCeiling() ;
void billboardCylindricalBegin(float x, float y, float z, float p, float d, float q);
void makeAgus1House(int i, int j) ;
void makeAgus2House(int i, int j) ;
void makeATile(int i, int j, int height) ;
void makeATile(int i, int j, int height, float width) ;
void makeAGroundLight(int i, int j) ;
void makeTree(int i, int j, int x, int y) ;
void makeTree1(int i, int j) ;

void makeFog();
void initFog() ;

extern GLfloat fogColor[4] ;


//*************************************************
//       Init Fog (not used)
//*************************************************
void initFog(){
    GLuint fogMode[]= { GL_EXP, GL_EXP2, GL_LINEAR };	// Storage For Three Types Of Fog
    GLuint fogfilter= 3;					// Which Fog To Use

    glClearColor(0.5f,0.5f,0.5f,1.0f);			// We'll Clear To The Color Of The Fog ( Modified )

    glFogi(GL_FOG_MODE, fogMode[fogfilter]);		// Fog Mode
    glFogfv(GL_FOG_COLOR, fogColor);			// Set Fog Color
    glFogf(GL_FOG_DENSITY, 0.0005f);				// How Dense Will The Fog Be
    glHint(GL_FOG_HINT, GL_NICEST);			// Fog Hint Value
    glFogf(GL_FOG_START, 100.0f);				// Fog Start Depth
    glFogf(GL_FOG_END, 1000.0f);				// Fog End Depth
    glEnable(GL_FOG);					// Enables GL_FOG
}



//*************************************************
//       Make Fog
//*************************************************
void makeFog() {
    if (timeOfDay == '9') {
        for (int i=0;i<3;i++){
            fogColor[i]=.3f ;
        }
    } else {
            for (int i=0;i<3;i++){
               fogColor[i]=.8f ;
            }
    }
}


//*************************************************
//       Make Terrain
//*************************************************

void makeTerrain() {

    int x,z;
    glColor3f(0, 0.5, 0.1);         
    glBegin(GL_TRIANGLE_STRIP);
    for(x = 0; x < AREA_SIZE-step; x+=step)
    {
        for(z = 0; z < AREA_SIZE-step; z+=step)
        {
            glVertex3f(F*(x+step), F*height_field[x+step][z], F*z);
            glVertex3f(F*x, F*height_field[x][z], F*z);
        }
    }
    glEnd();

}



void handleBeginning(float &myX, float &myY, float &slope, float &theta, int i) {
    
//    cout << "\nbeginning: figuring out data for points ("<< RoadArray[i] << ", " << RoadArray[i+1] << ") (" << RoadArray[i+2]<< ", "  << RoadArray[i+3]<<") \n" ;

    // figure out theta (angle of slope of line)
    // first make sure it's not inf or 0
    if (((RoadArray[i+2] - RoadArray[i]) != 0) && ((RoadArray[i+3] - RoadArray[i+1]) != 0)) {
        slope = (RoadArray[i+3] - RoadArray[i+1])/(RoadArray[i+2] - RoadArray[i]);

        slope = -1/slope ;
        theta = atan(slope) ;

        //			cout << "slope ="<<slope <<"  theta ="<<theta<<"\n"; 

        myY = 5*(cos(theta)) ;
        myX = 5*(sin(theta)) ;

    } else { // slope is either inf or 0

        if ((RoadArray[i+2] - RoadArray[i]) != 0) {
            myX = 5 ;
            myY = 0 ; } else {

                myX = 0 ;
                myY = 5 ;
            }
    }

//    cout << "so data around points ("<< RoadArray[i] << ", " << RoadArray[i+1] << ") is ("<< (RoadArray[i])+(myY) << ", "<<(RoadArray[i+1])+(myX) << ") and (" <<  (RoadArray[i])-(myY) << ", "<<(RoadArray[i+1])-(myX)<< ")\n";


    glVertex3f( ((RoadArray[i])+(myY)), -4.6, ((RoadArray[i+1])+(myX)));
    glVertex3f( ((RoadArray[i])-(myY)), -4.6, ((RoadArray[i+1])-(myX)));
    
        
}

void handleEndpoint(float &myX, float &myY, float &slope, float &theta, int i) {
    // do this for the endpoint of a road.

//    cout << "reached an endpoint at "<< RoadArray[i] <<","<<(RoadArray[i+1])<<"\n"; 

    // use previous slope

//    cout << "\nfiguring out data for points ("<< RoadArray[i] << ", " << RoadArray[i+1] << ") (" << RoadArray[i+2]<< ", "  << RoadArray[i+3]<<") \n" ;

    // figure out theta (angle of slope of line)
    if (((RoadArray[i] - RoadArray[i-2]) != 0) && ((RoadArray[i+1] - RoadArray[i-1]) != 0)) {
        slope = (RoadArray[i+1] - RoadArray[i-1])/(RoadArray[i] - RoadArray[i-2]);
        slope = -1/slope ;
        theta = atan(slope) ;

        //cout << "slope ="<<slope <<"  theta ="<<theta<<"\n"; 

        myY = 5*(cos(theta)) ;
        myX = 5*(sin(theta)) ;

    } else { // slope is either inf or 0

        if ((RoadArray[i] - RoadArray[i-2]) != 0) { // then slope is 0
            myX = 5 ;
            myY = 0 ; }
        else {

            myX = 0 ;
            myY = 5 ;
        } ;
    }

//    cout << "so data around points ("<< RoadArray[i] << ", " << RoadArray[i+1] << ") is ("<< (RoadArray[i])+(myY) << ", "<<(RoadArray[i+1])+(myX) << ") and (" <<  (RoadArray[i])-(myY) << ", "<<(RoadArray[i+1])-(myX)<< ")\n";


    glVertex3f( ((RoadArray[i])+(myY)), -4.6, ((RoadArray[i+1])+(myX)));
    glVertex3f( ((RoadArray[i])-(myY)), -4.6, ((RoadArray[i+1])-(myX)));
    
}

void handleMidpoint(float &myX, float &myY, float &slope, float &slope1, float &theta, int i) {
    // middle area of a road: use previous + next slope averaged.

//    cout << "\nmiddle: figuring out data for points ("<< RoadArray[i] << ", " << RoadArray[i+1] << ") (" << RoadArray[i+2]<< ", "  << RoadArray[i+3]<<") \n" ;

    // figure out theta (angle of slope of line)
    if ((((RoadArray[i] - RoadArray[i-2]) != 0) && ((RoadArray[i+1] - RoadArray[i-1]) != 0)) && ( (((RoadArray[i+2] - RoadArray[i]) != 0) && ((RoadArray[i+3] - RoadArray[i+1]) != 0)) ))

    {
        slope = (RoadArray[i+1] - RoadArray[i-1])/(RoadArray[i] - RoadArray[i-2]);
        slope = -1/slope ;

        // figure out slope1 			
        slope1 = (RoadArray[i+3] - RoadArray[i+1])/(RoadArray[i+2] - RoadArray[i]);
        slope1 = -1/slope1 ;

        // take the average of the slopes
        slope = (slope + slope1)/2 ;

        theta = atan(slope) ;

        // cout << "slope ="<<slope <<"  theta ="<<theta<<"\n"; 

        myY = 5*(cos(theta)) ;
        myX = 5*(sin(theta)) ;

    } else { // some road's slope is either inf or 0 -- this is NOT DONE YET

        // need to check to see which roads have the 0 or infinite slope. 
    
        if ((RoadArray[i] - RoadArray[i-2]) == 0) { // the first road has an infinite slope
            if ((RoadArray[i+3] - RoadArray[i+1]) == 0) { // and the second road has a 0 slope
//                cout << "a\n" ;
                theta = atan(1.0) ;
 //               myX = 5 ;
 //               myY = 0 ;
            } else {
                // use 2nd road normal
                slope = (RoadArray[i+3] - RoadArray[i+1])/(RoadArray[i+2] - RoadArray[i]);
                slope = -1/slope ;
                theta = atan(slope) ;
                myY = 5*(cos(theta)) ;
                myX = 5*(sin(theta)) ;
//          cout << "b\n" ;
            }
        }
      
        
    if ((RoadArray[i+1] - RoadArray[i-1]) == 0) { // the first road has a 0 slope
        if ((RoadArray[i+2] - RoadArray[i]) == 0) { // and the second road has an inf slope
            theta = atan(-1.0) ;


//          cout << "c\n" ;
        } else {
            // use 2nd road normal
            slope = (RoadArray[i+3] - RoadArray[i+1])/(RoadArray[i+2] - RoadArray[i]);
            slope = -1/slope ;
            theta = atan(slope) ;
            myY = 5*(cos(theta)) ;
            myX = 5*(sin(theta)) ;
//          cout << "d\n" ;
        }
    }


        myX = 5*(cos(theta)) ;
        myY = 5*(sin(theta)) ;
        
/*    if ((RoadArray[i+3] - RoadArray[i+1]) == 0) { // the second road has a 0 slope
        if ((RoadArray[i+2] - RoadArray[i]) == 0) { // and the second road has an inf slope
            theta = atan(-1.0) ;
                 cout << "f\n" ;
        } else {
            // use 1st road normal
            slope = (RoadArray[i+1] - RoadArray[i-1])/(RoadArray[i] - RoadArray[i-2]);
            slope = -1/slope ;
            theta = atan(slope) ;
          cout << "g\n" ;
        }
    }
        

        
    if ((RoadArray[i+2] - RoadArray[i]) == 0) { // the second road has an infinite slope
        if ((RoadArray[i+2] - RoadArray[i]) == 0) { // and the second road has an inf slope
            theta = atan(-1.0) ;
           cout << "h\n" ;
        } else {
            // use 1st road normal
            slope = (RoadArray[i+1] - RoadArray[i-1])/(RoadArray[i] - RoadArray[i-2]);
            slope = -1/slope ;
            theta = atan(slope) ;
            cout << "i\n" ;
        }
    }
        cout << "theta = "<< theta << endl ;
*/
        


        

/*
        if ((RoadArray[i] - RoadArray[i-2]) == 0) {
            myX = 5 ;
            myY = 0 ; } else {

                myX = 0 ;
                myY = 5 ;
        } ;
*/


    }

//    cout << "so data around points ("<< RoadArray[i] << ", " << RoadArray[i+1] << ") is ("<< (RoadArray[i])+(myY) << ", "<<(RoadArray[i+1])+(myX) << ") and (" <<  (RoadArray[i])-(myY) << ", "<<(RoadArray[i+1])-(myX)<< ")\n";


    glVertex3f( ((RoadArray[i])+(myY)), -4.6, ((RoadArray[i+1])+(myX)));
    glVertex3f( ((RoadArray[i])-(myY)), -4.6, ((RoadArray[i+1])-(myX)));

}

void letterbox(string testWords, float x, float y, float z){

    int letterInt;
    //    cout << "testWords = "<< testWords << endl ;


    for(int i=0; i < testWords.size(); i++){
        // A = 65, 1 = 48
        letterInt = testWords[i];

        if ((letterInt <= 57) && (letterInt >= 48)) {
            letterInt = testWords[i] - 48 + 26; }
        else {
            letterInt = letterInt - 65;

        };

        //      cout << letterInt << "\n";
        if(letterInt >= 0){
//            cout << "activating texture " << letterInt << endl ;
            (alphaTexture[letterInt]).activate();
            glBegin(GL_QUADS);
            glColor3f(1.0,.8,.8);
            glTexCoord2f(1,0);
            glVertex3f(x+i,y,z);
            glTexCoord2f(1,1);
            glVertex3f(x+i,y+1,z);
            glTexCoord2f(0,1);
            glVertex3f(x+1+i,y+1,z);
            glTexCoord2f(0,0);
            glVertex3f(x+1+i,y,z);
            glEnd();
            (alphaTexture[letterInt]).deactivate();
        }
    }

}

void letterbox1(string testWords, float x, float y, float z){

    int letterInt;
//    cout << "testWords = "<< testWords << endl ;

    
    for(int i=0; i < testWords.size(); i++){
        // A = 65, 1 = 48
        letterInt = testWords[i];


        letterInt = letterInt - 48;
        
            
  //      cout << letterInt << "\n";
        if ((letterInt >= 0) && (letterInt <= 9)){
//            cout << "activating texture " << letterInt << "at " << x+i <<", " << z << endl ;

             glPushMatrix() ;

/*            glPushMatrix() ;
            glColor3f(1.0f, 0, 1.0f) ;
            glTranslatef(x+i, 60, z) ;
            glutSolidCube(100) ;
            glPopMatrix() ;
*/            
            (numberTexture[letterInt]).activate();
            glBegin(GL_QUADS);
            glColor3f(1.0,.8,.8);
            glTexCoord2f(1,0);
            glVertex3f(x+10*i,y,z);
            glTexCoord2f(1,1);
            glVertex3f(x+10*i,y+30,z);
            glTexCoord2f(0,1);
            glVertex3f(x+10+10*i,y+30,z);
            glTexCoord2f(0,0);
            glVertex3f(x+10+10*i,y,z);
            glEnd();
            
            (numberTexture[letterInt]).deactivate();

             glPopMatrix() ;
        }
    }

        
}

//*****************************************************

// DO ROADS

// Connect some dots to make roads.

//*****************************************************
void displayPolyRoads(void)

{
    int i= 0;
    int roads=0;
    float theta=0.0;
    float slope=0.0;
    float slope1=0.0;
    float myX = 0.0;
    float myY = 0.0;

    glNewList(startList + 2, GL_COMPILE);

    // Draw a quad strip

            
    glColor3f(0.3f, 0.3f, 0.3f);	

    printf ("i = %d, number of road nodes is %d\n", i, number_of_road_nodes) ;

    while (i <= number_of_road_nodes) {

            glBegin( GL_TRIANGLE_STRIP );
        
            handleBeginning(myX, myY, slope, theta, i) ;
            // Figure out how to get points around the road's center. There
            // are three cases for this; 
            // 1) We're at a beginning point of a road
            // 2) We are at an endpoint of a road, w/ no new roads
            // 3) We are at an endpoint of a road, w/ new roads
            // 3) We are in the middle somewhere (bisect the angle; average the slopes)

            i=i+2 ;
            
            while (((RoadArray[i+2]) != -1) && ((i+2) < number_of_road_nodes)) { // we are middle of a road.
                handleMidpoint(myX, myY, slope, slope1, theta, i) ;
                i= i+2 ;
            } ;

            handleEndpoint(myX, myY, slope, theta, i) ;
            i=i+3;
            glEnd();
    } ;
    
    glEndList() ;
    glFlush();
}




//**************************************************************
// Make A Tree

// This needs to be called separately from the houses, 
// so the background of the trees can blend in (transparent).
// They need to be printed in a spiral order.
//**************************************************************

void makeATree(int i, int j, int rowImOn, int colImOn)
{

    int cellData;

    /*
    float heightScale, widthScale ;
     int temp = 0;
     int newI, newJ ;
     */

    if ( ((i <= MAX_COLUMNS-1)&&(i >= 0))&&((j <= MAX_ROWS-1) && (j >= 0)))
    {

        cellData = (*whatDataBasePtr)[i][j];

        glPushMatrix();

        //      cout << "checking location at x= "<<i<<", z=" << j <<"\n";

        // figure out what the object should be
        switch (cellData) {

            case 41: case 42: case 43: case 51: case 61: case 71: // it's a tree

                makeTree(i, j, rowImOn, colImOn) ;
//				makeTree1(i, j) ;

                break;

            default:
                break;

        }

        glPopMatrix();

    }

}



//*************************************************

//       Make Tree

//*************************************************

void makeTree(int i, int j, int rowImOn, int colImOn) {

        if (timeOfDay == '8') {
        glColor3f(1,1,1);
        } else {
        glColor3f(.3,.3,.3);
        }
        
        

    int jitter = 4 - (((i*j)^2)%10);
    int newI = (i*xplot) + jitter ; // randomArray[i][j].jitterX ;
    int newJ = (j*zplot) + jitter ; // randomArray[i][j].jitterY ;
        // vary the tree's size
 
        glPushMatrix() ;
		
        glTranslatef(newI,0,newJ);

        float heightScale = 1.0 + .2*(((i*j)^2)%5) ;
        float widthScale = 1.0 + .1*(((i*j)^3)%7) ; 
        glScalef(widthScale,heightScale,widthScale);

        billboardCylindricalBegin(headX,headY,headZ,newI,0,newJ);

        int aTextureOffset = ((i*j)^3)%4 ; // (randomArray[i][j].texture)%4 ;

        (myTreeTexture+aTextureOffset)->activate() ;
	
		glBegin(GL_QUADS) ;

		glTexCoord2f(1,0);
		glVertex3f(6,-5,-6);

		glTexCoord2f(1,1);
		glVertex3f(6,12,-6);

		glTexCoord2f(0,1);
		glVertex3f(-6,12,-6);

		glTexCoord2f(0,0);
		glVertex3f(-6,-5,-6);

		glEnd();


		(myTreeTexture+aTextureOffset)->deactivate() ;
		glPopMatrix() ;

// **** adding a new tree

		// now figure out the vector between your head and the NewI, 0, newJ
		// and then subtract a bit from it and stick a new tree there, closer
		// to your head.

		// so figure out the newI and newJ.

  //              myHeadPositionInWorldCoordinate + 0.5*(theTreePosition - myHeadPositionInWorldCoordinate) ;
		

		arVector3 NewIJ = ar_pointToNavCoords(arVector3(rowImOn*xplot, 0, colImOn*zplot))+.2*((arVector3(newI, 0, newJ)) - ar_pointToNavCoords(arVector3(rowImOn*xplot, 0, colImOn*zplot))) ;
//		cout << "NewIJ = " << NewIJ << endl ;

		// vary the tree's size
 
		glPushMatrix() ;
		
		glTranslatef(NewIJ[0],0,NewIJ[2]);
        
        glScalef(widthScale+1,heightScale+1,widthScale);

        billboardCylindricalBegin(rowImOn*xplot,0,colImOn*zplot,NewIJ[0],0,NewIJ[2]);

        aTextureOffset = ((i+1+j)^4)%4 ;

        (myTreeTexture+aTextureOffset)->activate() ;
	
		glBegin(GL_QUADS) ;

		glTexCoord2f(1,0);
		glVertex3f(6,-5,-6);

		glTexCoord2f(1,1);
		glVertex3f(6,12,-6);

		glTexCoord2f(0,1);
		glVertex3f(-6,12,-6);

		glTexCoord2f(0,0);
		glVertex3f(-6,-5,-6);

		glEnd();


		(myTreeTexture+aTextureOffset)->deactivate() ;
		glPopMatrix() ;

		// end adding a new tree

 
}



//*************************************************

//       Billboard a Tree

//*************************************************

void billboardCylindricalBegin(

	float camX, float camY, float camZ,
	float objPosX, float objPosY, float objPosZ) {

//	float lookAt[3],objToCamProj[3],upAux[3];
//	float modelview[16],
	float angleCosine;

	arVector3 objToCamProjV ;
	arVector3 lookAtV ;
	arVector3 upAuxV ;


// objToCamProj is the vector in world coordinates from the 
// local origin to the camera projected in the XZ plane

	objToCamProjV[0] = camX - objPosX ;
	objToCamProjV[1] = 0;
	objToCamProjV[2] = camZ - objPosZ ;

	
// This is the original lookAt vector for the object 
// in world coordinates

	lookAtV[0] = 0;
	lookAtV[1] = 0;
	lookAtV[2] = 1;

// normalize both vectors to get the cosine directly afterwards

	objToCamProjV = objToCamProjV.normalize();

// easy fix to determine whether the angle is negative or positive
// for positive angles upAux will be a vector pointing in the 
// positive y direction, otherwise upAux will point downwards
// effectively reversing the rotation.

//	mathsCrossProduct(upAuxV,lookAtV,objToCamProjV);
	upAuxV = lookAtV * objToCamProjV ; 

// compute the angle
	angleCosine = lookAtV % objToCamProjV;

// perform the rotation. The if statement is used for stability reasons
// if the lookAt and objToCamProj vectors are too close together then 
// |angleCosine| could be bigger than 1 due to lack of precision

   if ((angleCosine < 0.99990) && (angleCosine > -0.9999))
      glRotatef(acos(angleCosine)*180/3.14,upAuxV[0], upAuxV[1], upAuxV[2]);	

//   glPopMatrix();
}


//*****************************************************

// ********   Do Trees

//*****************************************************

void makeABoxOfTrees (int rowImOn, int colImOn, int num_to_display)
{
    int startRow = rowImOn ;
    int startCol = colImOn ;
    int i, j ;

    j = startRow ;
    for (i=startCol; i<=(startCol + num_to_display); i++) {
        makeATree(i, j, rowImOn, colImOn) ;    
    }
    j = startRow + num_to_display ;
    for (i=startCol; i<=(startCol + num_to_display); i++) {
        makeATree(i, j, rowImOn, colImOn) ;    
    }
    i = startCol ;
    for (j=startRow+1; j<=((startRow + num_to_display)-1); j++) {
        makeATree(i, j, rowImOn, colImOn) ;    
    }
    i = startCol + num_to_display ;
    for (j=startRow+1; j<=((startRow + num_to_display)-1); j++) {
        makeATree(i, j, rowImOn, colImOn) ;    
    }

}


void doTrees(int rowImOn, int colImOn)
{	
    //int myRows_to_display = rows_to_display ;
    //int myCols_to_display = cols_to_display ;

    int startRow = rowImOn - (rows_to_display/2) ;
    int startCol = colImOn - (cols_to_display/2) ;


    for (int x = cols_to_display; x >= 0; x=x-2 , startRow++, startCol++){

        //int x = cols_to_display ;
        //    cout << "making "<< x << " rows of trees for "<< startRow << " ," << startCol << " at pos " << rowImOn <<", "<<colImOn<<"\n";


        makeABoxOfTrees( startRow, startCol, x) ;


    }
}


//*************************************************
//       Make Residential House
//*************************************************
void makeRes(int i, int j) {


    char jitterX = 4 - (((i*j)^3)%10); // randomArray[i][j].jitterX ;
    char jitterY = 4 - (((i*j)^5)%10); // randomArray[i][j].jitterY ;
    glTranslatef(((i*xplot)+jitterX),0,((j*zplot)+jitterY));
    float heightScale = 1.0 + .1*(((i*j)^2)%5) ;
    glScalef(1.0, heightScale, 1.0);

    // the first three are small houses and the last 4 are big ones.
    char texture = ((i*j)^3)%7; // randomArray[i][j].texture ;
    
    if (texture > 3) {
//        if ((((i*j)^2)%5) > 3) {
        makeBigHouse(texture) ;}
        else {
            makeHouse(texture%2) ;};


}

//*************************************************
//       Make House
//*************************************************

void makeHouse(char temp) {

        (myHouseTexture+temp)->activate() ;


	glBegin(GL_QUADS) ;
	// Front panel (I think)


	glTexCoord2f(.5,.8);
	glVertex3f(5,5,5);
	glTexCoord2f(1,.8);
	glVertex3f(-5,5,5);

	glTexCoord2f(1,.5);	
	glVertex3f(-5,-5,5);
        
	glTexCoord2f(.5,.5);
        glVertex3f(5,-5,5);
        
	
        // A D
	// B C
	glTexCoord2f(0,.5);
	glVertex3f(5,5,-5);

	glTexCoord2f(0,0);
	glVertex3f(5,-5,-5);

        glTexCoord2f(.5,0);
	glVertex3f(-5,-5,-5);

	glTexCoord2f(.5,.5);
        glVertex3f(-5,5,-5);
        
	// side panels

	glTexCoord2f(.5,.5);
	glVertex3f(-5,5,5);

	glTexCoord2f(1,.5);
	glVertex3f(-5,5,-5);
    
	glTexCoord2f(1,0);
	glVertex3f(-5,-5,-5);
    
	glTexCoord2f(.5,0);
	glVertex3f(-5,-5,5);

	glTexCoord2f(.5,0);
	glVertex3f(5,-5,5);
	glTexCoord2f(1,0);
	glVertex3f(5,-5,-5);
	glTexCoord2f(1,.5);
	glVertex3f(5,5,-5);

	glTexCoord2f(.5,.5);
	glVertex3f(5,5,5);

	// rooftops
//	glColor3f(.1,.1,.4);

	//  C D
	//	B A
	glTexCoord2f(.5,.5);
	glVertex3f(6,5,6);

	glTexCoord2f(0,.5);
	glVertex3f(6,5,-6);

	glTexCoord2f(0,1);
	glVertex3f(0,12,-6);
        glTexCoord2f(.5,1);
	glVertex3f(0,12,6);

	glTexCoord2f(.5,.5);
	glVertex3f(-6,5,6);

	glTexCoord2f(0,.5);
	glVertex3f(0,12,6);
        glTexCoord2f(0,1);
        glVertex3f(0,12,-6);
	
	glTexCoord2f(.5,1);
	glVertex3f(-6,5,-5);
	glEnd(); 

	glBegin(GL_TRIANGLES) ;

        glTexCoord2f(1,.80);
	glVertex3f(-6,5,5);

	glTexCoord2f(.75,1);
	glVertex3f(0,12,5);

	glTexCoord2f(.5,.81);
	glVertex3f(6,5,5);

	glTexCoord2f(1,.80);
	glVertex3f(-6,5,-5);

	glTexCoord2f(.75,1);
	glVertex3f(0,12,-5);

	glTexCoord2f(.5,.81);
	glVertex3f(6,5,-5);

	glEnd();

        
        (myHouseTexture+temp)->deactivate() ;


}


//*************************************************
//       Make A 2 Story House with Textures
//*************************************************


void makeBigHouse(char temp) {

        (myHouseTexture+temp)->activate() ;  // big houses start at houseTextureArray 4

	glBegin(GL_QUADS) ;
	// Front panel (I think)

	// A B
	// D C

	glTexCoord2f(.5,.8);
	glVertex3f(5,9,5);
	glTexCoord2f(1,.8);
	glVertex3f(-5,9,5);

	glTexCoord2f(1,.5);	
	glVertex3f(-5,-5,5);
        
	glTexCoord2f(.5,.5);
        glVertex3f(5,-5,5);
        
	
        // A D
	// B C
	glTexCoord2f(0,.5);
	glVertex3f(5,9,-5);

	glTexCoord2f(0,0);
	glVertex3f(5,-5,-5);

        glTexCoord2f(.5,0);
	glVertex3f(-5,-5,-5);

	glTexCoord2f(.5,.5);
        glVertex3f(-5,9,-5);
        
	// side panels

	glTexCoord2f(.5,.5);
	glVertex3f(-5,9,5);

	glTexCoord2f(1,.5);
	glVertex3f(-5,9,-5);
    
	glTexCoord2f(1,0);
	glVertex3f(-5,-5,-5);
    
	glTexCoord2f(.5,0);
	glVertex3f(-5,-5,5);

	glTexCoord2f(.5,0);
	glVertex3f(5,-5,5);
	glTexCoord2f(1,0);
	glVertex3f(5,-5,-5);
	glTexCoord2f(1,.5);
	glVertex3f(5,9,-5);

	glTexCoord2f(.5,.5);
	glVertex3f(5,9,5);

	// rooftops
//	glColor3f(.1,.1,.4);

	//  C D
	//	B A
	glTexCoord2f(.5,.5);
	glVertex3f(6,9,6);

	glTexCoord2f(0,.5);
	glVertex3f(6,9,-6);

	glTexCoord2f(0,1);
	glVertex3f(0,17,-6);
        glTexCoord2f(.5,1);
	glVertex3f(0,17,6);

	glTexCoord2f(.5,.5);
	glVertex3f(-6,9,6);

	glTexCoord2f(0,.5);
	glVertex3f(0,17,6);
        glTexCoord2f(0,1);
        glVertex3f(0,17,-6);
	
	glTexCoord2f(.5,1);
	glVertex3f(-6,9,-5);
	glEnd(); 

	glBegin(GL_TRIANGLES) ;

        glTexCoord2f(1,.80);
	glVertex3f(-6,9,5);

	glTexCoord2f(.75,1);
	glVertex3f(0,17,5);

	glTexCoord2f(.5,.81);
	glVertex3f(6,9,5);

	glTexCoord2f(1,.80);
	glVertex3f(-6,9,-5);

	glTexCoord2f(.75,1);
	glVertex3f(0,17,-5);

	glTexCoord2f(.5,.81);
	glVertex3f(6,9,-5);

	glEnd();

              
        (myHouseTexture+temp+3)->deactivate() ;  // big houses start at houseTextureArray 4

}


//*************************************************
//       Make Car
//*************************************************

void makeCar(float R, float G, float B) {

    float frontZ = 1.6; float longest = 3.66 ; float tallest = 2.0 ;
    float tallerest = 3.0 ;

    static GLfloat vertices[20][3] = {
    {0, 0, frontZ},
    {longest, 0, frontZ},
    {longest, tallest-.6, frontZ},
    {longest-2.0, tallest, frontZ},
    {longest-2.6, tallerest, frontZ},
    {0, tallerest, frontZ},
    {-1, tallest, frontZ},
    {-longest+.6, tallest, frontZ},
    {-longest, 0, frontZ},

    {0, 0, -frontZ},
    {longest, 0, -frontZ},
    {longest, tallest-.6, -frontZ},
    {longest-2.0, tallest, -frontZ},
    {longest-2.6, tallerest, -frontZ},
    {0, tallerest, -frontZ},
    {-1, tallest, -frontZ},
    {-longest+.6, tallest, -frontZ},
    {-longest, 0, -frontZ}

    };

    glColor3f( R, G, B );
    //    cout << R << ", " << G << ", " << B << endl; 
    glBegin( GL_POLYGON );
    glVertex3fv(vertices[0]);
    glVertex3fv(vertices[1]);
    glVertex3fv(vertices[2]);
    glVertex3fv(vertices[3]);
    glVertex3fv(vertices[4]);
    glVertex3fv(vertices[5]);
    glVertex3fv(vertices[6]);
    glVertex3fv(vertices[7]);
    glVertex3fv(vertices[8]);
    glEnd();

    //   glColor3f( 1.0, 0.0, 0.0 );
    glBegin( GL_POLYGON );
    glVertex3fv(vertices[9]);
    glVertex3fv(vertices[10]);
    glVertex3fv(vertices[11]);
    glVertex3fv(vertices[12]);
    glVertex3fv(vertices[13]);
    glVertex3fv(vertices[14]);
    glVertex3fv(vertices[15]);
    glVertex3fv(vertices[16]);
    glVertex3fv(vertices[17]);
    glEnd();

    // 
    glBegin( GL_QUADS) ;
    glVertex3fv(vertices[8]);
    glVertex3fv(vertices[7]);
    glVertex3fv(vertices[16]);
    glVertex3fv(vertices[17]);

    glVertex3fv(vertices[7]);
    glVertex3fv(vertices[16]);
    glVertex3fv(vertices[15]);
    glVertex3fv(vertices[6]);



    glVertex3fv(vertices[4]);
    glVertex3fv(vertices[5]);
    glVertex3fv(vertices[14]);
    glVertex3fv(vertices[13]);


    glVertex3fv(vertices[2]);
    glVertex3fv(vertices[3]);
    glVertex3fv(vertices[12]);
    glVertex3fv(vertices[11]);

    glVertex3fv(vertices[1]);
    glVertex3fv(vertices[2]);
    glVertex3fv(vertices[11]);
    glVertex3fv(vertices[10]);

    // windshield
    glColor3f( 0, 0.0, 0.0 );
    glVertex3fv(vertices[3]);
    glVertex3fv(vertices[4]);
    glVertex3fv(vertices[13]);
    glVertex3fv(vertices[12]);

    glVertex3fv(vertices[6]);
    glVertex3fv(vertices[15]);
    glVertex3fv(vertices[14]);
    glVertex3fv(vertices[5]);

    glEnd();



    //    (myHouseTexture+temp)->deactivate() ;


}

//*************************************************
//       Make Truck
//*************************************************

void makeTruck(float R, float G, float B) {

    float frontZ = 1.6; float longest = 3.0 ; float tallest = 3.0 ;
    float tallerest = 5.0 ; float cargoH = 1.75 ;

    static GLfloat vertices[24][3] = {
    {0, 0, frontZ},
    {longest, 0, frontZ},
    {longest, tallest, frontZ},
    {longest-1.0, tallest, frontZ},
    {longest-2.0, tallerest, frontZ},
    {longest-2.0, tallerest+1, frontZ},
    {0, tallerest+1, frontZ},
    {-.4, 0, frontZ},
    {-.4, tallerest+cargoH, frontZ},
    {-longest-6, tallerest+cargoH, frontZ},
    {-longest-6, 0, frontZ},
        
    {0, 0, -frontZ},
    {longest, 0, -frontZ},
    {longest, tallest, -frontZ},
    {longest-1.0, tallest, -frontZ},
    {longest-2.0, tallerest, -frontZ},
    {longest-2.0, tallerest+1, -frontZ},
    {0, tallerest+1, -frontZ},
    {-.4, 0, -frontZ},
    {-.4, tallerest+cargoH, -frontZ},
    {-longest-6, tallerest+cargoH, -frontZ},
    {-longest-6, 0, -frontZ},
        
    };
    
    glColor3f( R, G, B );
//    cout << R << ", " << G << ", " << B << endl; 
    glBegin( GL_POLYGON );
    glVertex3fv(vertices[0]);
    glVertex3fv(vertices[1]);
    glVertex3fv(vertices[2]);
    glVertex3fv(vertices[3]);
    glVertex3fv(vertices[4]);
    glVertex3fv(vertices[5]);
    glVertex3fv(vertices[6]);
    glEnd();
    
    glBegin( GL_POLYGON) ;
    glVertex3fv(vertices[7]);
    glVertex3fv(vertices[8]);
    glVertex3fv(vertices[9]);
    glVertex3fv(vertices[10]);
    glEnd();
    
 //   glColor3f( 1.0, 0.0, 0.0 );
    glBegin( GL_POLYGON );

    glVertex3fv(vertices[11]);
    glVertex3fv(vertices[12]);
    glVertex3fv(vertices[13]);
    glVertex3fv(vertices[14]);
    glVertex3fv(vertices[15]);
    glVertex3fv(vertices[16]);
    glVertex3fv(vertices[17]);
    glEnd();
    
    glBegin( GL_POLYGON );
    glVertex3fv(vertices[18]);
    glVertex3fv(vertices[19]);
    glVertex3fv(vertices[20]);
    glVertex3fv(vertices[21]);
    glEnd();

    // 
    glBegin( GL_QUADS) ;

    glVertex3fv(vertices[1]);
    glVertex3fv(vertices[12]);
    glVertex3fv(vertices[13]);
    glVertex3fv(vertices[2]);

    glVertex3fv(vertices[2]);
    glVertex3fv(vertices[3]);
    glVertex3fv(vertices[14]);
    glVertex3fv(vertices[13]);


    glVertex3fv(vertices[4]);
    glVertex3fv(vertices[5]);
    glVertex3fv(vertices[16]);
    glVertex3fv(vertices[15]);

    glVertex3fv(vertices[5]);
    glVertex3fv(vertices[6]);
    glVertex3fv(vertices[17]);
    glVertex3fv(vertices[16]);

    glVertex3fv(vertices[6]);
    glVertex3fv(vertices[7]);
    glVertex3fv(vertices[18]);
    glVertex3fv(vertices[17]);

    glVertex3fv(vertices[8]);
    glVertex3fv(vertices[9]);
    glVertex3fv(vertices[19]);
    glVertex3fv(vertices[18]);

    glVertex3fv(vertices[9]);
    glVertex3fv(vertices[10]);
    glVertex3fv(vertices[20]);
    glVertex3fv(vertices[19]);

    glVertex3fv(vertices[11]);
    glVertex3fv(vertices[10]);
    glVertex3fv(vertices[21]);
    glVertex3fv(vertices[20]);

    
	glEnd();
        
 glColor3f( 0.0, 0.0, 0.0 );
    glBegin( GL_QUADS) ;
        glVertex3fv(vertices[3]);
        glVertex3fv(vertices[4]);
        glVertex3fv(vertices[15]);
        glVertex3fv(vertices[14]);
        glEnd() ;
        
//    (myHouseTexture+temp)->deactivate() ;


}



//*************************************************
//       Make Commercial Building
//*************************************************

void makeBld(int i, int j) {

//        int jitter = 4 - (((i*j)^2)%10);
    
    char jitterX = 4 - (((i*j)^5)%10); // randomArray[i][j].jitterX ;
    char jitterY = 4 - (((i*j)^3)%10); // randomArray[i][j].jitterY ;
    
    glTranslatef(((i*xplot)+jitterX),0,((j*zplot)+jitterY));
    float heightScale = 1.0 + .1*(((i*j)^2)%5) ;
    glScalef(1.0, heightScale, 1.0);

        char temp = ((i+j)^4)%4 ;

        (myBldTexture+temp)->activate() ;


//	house1Texture.activate() ;
	glBegin(GL_QUADS) ;
	// Front panel (I think)


	// B A
	// C D

	glTexCoord2f(1,1);
	glVertex3f(5,bldTop,5);
	glTexCoord2f(0,1);
	glVertex3f(-5,bldTop,5);

	glTexCoord2f(0,0);	
	glVertex3f(-5,bldBottom,5);
        
	glTexCoord2f(1,0);
        glVertex3f(5,bldBottom,5);
        
	
        // D A
	// C B
	glTexCoord2f(1,1);
	glVertex3f(5,bldTop,-5);

	glTexCoord2f(1,0);
	glVertex3f(5,bldBottom,-5);

        glTexCoord2f(0,0);
	glVertex3f(-5,bldBottom,-5);

	glTexCoord2f(0,1);
        glVertex3f(-5,bldTop,-5);
        
	// side panels

	glTexCoord2f(1,1);
	glVertex3f(-5,bldTop,5);

	glTexCoord2f(0,1);
	glVertex3f(-5,bldTop,-5);
    
	glTexCoord2f(0,0);
	glVertex3f(-5,bldBottom,-5);
    
	glTexCoord2f(1,0);
	glVertex3f(-5,bldBottom,5);

	glTexCoord2f(0,0);
	glVertex3f(5,bldBottom,5);
	glTexCoord2f(1,0);
	glVertex3f(5,bldBottom,-5);
	glTexCoord2f(1,1);
	glVertex3f(5,bldTop,-5);
	glTexCoord2f(0,1);
	glVertex3f(5,bldTop,5);

	// rooftops
      	glColor3f(.3,.3,.3) ;
	glVertex3f(-5,bldTop,-5);
        glVertex3f(-5,bldTop,5);
        glVertex3f(5,bldTop,5);
    	glVertex3f(5,bldTop,-5);
        

	glEnd();

        (myBldTexture+temp)->deactivate() ;

}


void makeAgusResidential(int i, int j) {
    if ((i*j)%5 >= 3) {
    makeAgus1House(i, j) ; } else {makeAgus2House(i, j) ; }

}


//*************************************************
//       Make Agus 1 House
//*************************************************

void makeAgus1House(int i, int j) {

        int jitter = 4 - (((i*j)^2)%10);
        glTranslatef(((i*xplot)+jitter),0,((j*zplot)+jitter));
        float heightScale = 1.0 ; // + .1*(((i*j)^2)%5) ;
        glScalef(1.0,heightScale,1.0);

	Agus1Texture.activate() ;

	glBegin(GL_QUADS) ;
        
float Agus1FirstFlEdge = 9.1;
float Agus1FirstFlMid = 5 ; // Agus1FirstFlEdge - 5 ;
//float Agus1edge = 9.1; 
float garageR = 9 ;
float garageL = garageR - 7 ;
int Agus1FirstFlTop = 1; 
int Agus1Top = 4 ;
float ffTL = 0 ;
float ffTLL = 1 ;
float ffTR = .38 ;
float ffTT = .19 ;
float ffTB = 0 ;
//float tfTT = 1 ;
//float tfTL = .984 ;
//float tfTR = .239 ;

int sffTL = 1 ;
float sffTT = 1 ;
float sffTR = 0 ;
float sffTB = .805 ;

float smallWallT = .620 ;
float smallWallB = .46 ;
float smallWallR = .38 ;
float smallWallL = .6 ;


//float stfTT = .53 ;
//float stfTL = .984 ;
//float stfTR = .53 ;

//float cL = .508 ;
//float cR = 0 ;
float cT = .27 ;
float cB = 0 ;


// garage

	glTexCoord2f(ffTL,ffTT);
	glVertex3f(garageR,Agus1FirstFlTop,Agus1FirstFlEdge);
	glTexCoord2f(ffTR,ffTT);
	glVertex3f(garageL,Agus1FirstFlTop,Agus1FirstFlEdge);
	glTexCoord2f(ffTR,ffTB);	
	glVertex3f(garageL,bldBottom,Agus1FirstFlEdge);
	glTexCoord2f(ffTL,ffTB);
        glVertex3f(garageR,bldBottom,Agus1FirstFlEdge);        

// front

	glTexCoord2f(ffTR,ffTT);
	glVertex3f(garageL,Agus1FirstFlTop,Agus1FirstFlMid);
	glTexCoord2f(ffTLL,ffTT);
	glVertex3f(-Agus1FirstFlEdge,Agus1FirstFlTop,Agus1FirstFlMid);
	glTexCoord2f(ffTLL,ffTB);	
	glVertex3f(-Agus1FirstFlEdge,bldBottom,Agus1FirstFlMid);
	glTexCoord2f(ffTR,ffTB);
        glVertex3f(garageL,bldBottom,Agus1FirstFlMid);        

// back wall

 	glTexCoord2f(sffTL,sffTT);
	glVertex3f(Agus1FirstFlEdge,Agus1FirstFlTop,-Agus1FirstFlEdge);
	glTexCoord2f(sffTR,sffTT);
	glVertex3f(-Agus1FirstFlEdge,Agus1FirstFlTop,-Agus1FirstFlEdge);
	glTexCoord2f(sffTR,sffTB);
	glVertex3f(-Agus1FirstFlEdge,bldBottom,-Agus1FirstFlEdge);
	glTexCoord2f(sffTL,sffTB);
        glVertex3f(Agus1FirstFlEdge,bldBottom,-Agus1FirstFlEdge);   

 // right side wall
 	glTexCoord2f(sffTL,sffTB);
	glVertex3f(garageR,Agus1FirstFlTop,Agus1FirstFlEdge);
	glTexCoord2f(smallWallR,sffTB);
	glVertex3f(garageR,Agus1FirstFlTop,-Agus1FirstFlEdge);
	glTexCoord2f(smallWallR,smallWallT);
	glVertex3f(garageR,bldBottom,-Agus1FirstFlEdge);
	glTexCoord2f(sffTL,smallWallT);
	glVertex3f(garageR,bldBottom,Agus1FirstFlEdge);

 // middle side wall
 	glTexCoord2f(smallWallL,smallWallT);
	glVertex3f(garageL,Agus1FirstFlTop,Agus1FirstFlEdge);
	glTexCoord2f(smallWallR,smallWallT);
	glVertex3f(garageL,Agus1FirstFlTop,Agus1FirstFlMid);
	glTexCoord2f(smallWallR,smallWallB);
	glVertex3f(garageL,bldBottom,Agus1FirstFlMid);
	glTexCoord2f(smallWallL,smallWallB);
	glVertex3f(garageL,bldBottom,Agus1FirstFlEdge); 
        

 // left side wall
 	glTexCoord2f(1,smallWallT);
	glVertex3f(-Agus1FirstFlEdge,Agus1FirstFlTop,Agus1FirstFlMid);
	glTexCoord2f(smallWallR,smallWallT);
	glVertex3f(-Agus1FirstFlEdge,Agus1FirstFlTop,-Agus1FirstFlEdge);
	glTexCoord2f(smallWallR,smallWallB);
	glVertex3f(-Agus1FirstFlEdge,bldBottom,-Agus1FirstFlEdge);
	glTexCoord2f(1,smallWallB);
	glVertex3f(-Agus1FirstFlEdge,bldBottom,Agus1FirstFlMid); 

 // right roof quad
	glTexCoord2f(.39,smallWallB);
	glVertex3f(Agus1FirstFlEdge,Agus1FirstFlTop,Agus1FirstFlEdge);
	glTexCoord2f(.5,ffTT);
	glVertex3f((garageL-((garageL-garageR)/2.0)),Agus1Top,Agus1FirstFlEdge);
	glTexCoord2f(.7,ffTT);
	glVertex3f((garageL-((garageL-garageR)/2.0)),Agus1Top,(-Agus1FirstFlEdge)+((Agus1FirstFlEdge-Agus1FirstFlMid)/2.0));
 	glTexCoord2f(1,smallWallB);
	glVertex3f(Agus1FirstFlEdge,Agus1FirstFlTop,-Agus1FirstFlEdge); 
        
 // left roof quad
	glTexCoord2f(.39,smallWallB);
	glVertex3f(garageL,Agus1FirstFlTop,Agus1FirstFlEdge);
	glTexCoord2f(.5,ffTT);
	glVertex3f((garageL-((garageL-garageR)/2.0)),Agus1Top,Agus1FirstFlEdge);
	glTexCoord2f(.7,ffTT);
	glVertex3f((garageL-((garageL-garageR)/2.0)),Agus1Top,(-Agus1FirstFlEdge)+((Agus1FirstFlEdge-Agus1FirstFlMid)/2.0));
 	glTexCoord2f(1,smallWallB);
	glVertex3f(garageL,Agus1FirstFlTop,Agus1FirstFlMid); 
                                
 // front roof quad
 	glTexCoord2f(1,smallWallB);
	glVertex3f(-Agus1FirstFlEdge,Agus1FirstFlTop,Agus1FirstFlMid);
	glTexCoord2f(.7,ffTT);
	glVertex3f(-Agus1FirstFlEdge,Agus1Top,(-Agus1FirstFlEdge)+((Agus1FirstFlEdge-Agus1FirstFlMid)/2.0));
	glTexCoord2f(.5,ffTT);
	glVertex3f((garageL-((garageL-garageR)/2.0)),Agus1Top,(-Agus1FirstFlEdge)+((Agus1FirstFlEdge-Agus1FirstFlMid)/2.0));
	glTexCoord2f(.39,smallWallB);
	glVertex3f(garageL,Agus1FirstFlTop,Agus1FirstFlMid); 

 // back roof quad
 	glTexCoord2f(1,smallWallB);
	glVertex3f(-Agus1FirstFlEdge,Agus1FirstFlTop,-Agus1FirstFlEdge);
	glTexCoord2f(.7,ffTT);
	glVertex3f(-Agus1FirstFlEdge,Agus1Top,(-Agus1FirstFlEdge)+((Agus1FirstFlEdge-Agus1FirstFlMid)/2.0));
	glTexCoord2f(.5,ffTT);
	glVertex3f((garageL-((garageL-garageR)/2.0)),Agus1Top,(-Agus1FirstFlEdge)+((Agus1FirstFlEdge-Agus1FirstFlMid)/2.0));
	glTexCoord2f(.39,smallWallB);
	glVertex3f(garageR,Agus1FirstFlTop,-Agus1FirstFlEdge); 


        glEnd() ;


	glBegin(GL_TRIANGLES) ;
        
        // front yellow roof triangle

	glTexCoord2f(ffTR,ffTT);
	glVertex3f(garageL,Agus1FirstFlTop,Agus1FirstFlEdge);
	glTexCoord2f(ffTR/2.0  -.1,ffTT+.06);
	glVertex3f((garageL-((garageL-garageR)/2.0)), Agus1Top,Agus1FirstFlEdge);
	glTexCoord2f(0,ffTT);
	glVertex3f(garageR,Agus1FirstFlTop,Agus1FirstFlEdge);

        // side roof triangle

	glTexCoord2f(smallWallL,smallWallB);
	glVertex3f(-Agus1FirstFlEdge,Agus1FirstFlTop,-Agus1FirstFlEdge);
	glTexCoord2f(.7,ffTT);
	glVertex3f(-Agus1FirstFlEdge, Agus1Top,(-Agus1FirstFlEdge)+((Agus1FirstFlEdge-Agus1FirstFlMid)/2.0));
	glTexCoord2f(.4,smallWallB);
	glVertex3f(-Agus1FirstFlEdge,Agus1FirstFlTop,Agus1FirstFlMid);
        
        
	glEnd();

        
	Agus1Texture.deactivate() ;

}


void Agus2Roofs(float AgusZ) {
// left front
        glTexCoord2f(1,.91);
	glVertex3f(-AgusOutside, 1, AgusZ);
	glTexCoord2f(.8255,1);
	glVertex3f(((AgusOutside - AgusInside)/2) + -(AgusOutside), 3, AgusZ);
	glTexCoord2f(.651,.91);
	glVertex3f(-AgusInside, 1, AgusZ);

// right front
        glTexCoord2f(1,.91);
	glVertex3f(AgusInside, 1, AgusZ);
	glTexCoord2f(.8255,1);
	glVertex3f(((AgusOutside - AgusInside)/2) + AgusInside, 3, AgusZ);
	glTexCoord2f(.651,.91);
	glVertex3f(AgusOutside, 1, AgusZ);

}

void Agus2Sides (float AgusX) {
        
	glTexCoord2f(1, .29);
	glVertex3f(AgusX, AgusBottom, AgusFront);
	glTexCoord2f(.651, .29);
	glVertex3f(AgusX, AgusBottom, AgusBack);
	glTexCoord2f(.651, .57);
	glVertex3f(AgusX, 1, AgusBack);
	glTexCoord2f(1, .57);
	glVertex3f(AgusX, 1, AgusFront);

}

//*************************************************
//       Make Agus House Type 2
//*************************************************

void makeAgus2House(int i, int j) {

        // figure out some jitter
        int jitter = 4 - (((i*j)^2)%10);
        glTranslatef(((i*xplot)+jitter),0,((j*zplot)+jitter));
        float heightScale = 1.0 + .1*(((i*j)^2)%5) ;
        glScalef(1.0,heightScale,1.0);

	Agus2Texture.activate() ;

	glBegin(GL_QUADS) ;


// left front quad

	glTexCoord2f(1,.62);
	glVertex3f(-AgusOutside,AgusBottom, AgusFront);
	glTexCoord2f(.651,.62);
	glVertex3f(-AgusInside,AgusBottom, AgusFront);
	glTexCoord2f(.651,.91);	
	glVertex3f(-AgusInside, 1, AgusFront);        
	glTexCoord2f(1,.91);
        glVertex3f(-AgusOutside, 1, AgusFront);
        
// middle front quad

	glTexCoord2f(.65,.62);
	glVertex3f(-AgusInside, AgusBottom, AgusFront);
	glTexCoord2f(.35,.62);
	glVertex3f(AgusInside, AgusBottom, AgusFront);
	glTexCoord2f(.35,.78);	
	glVertex3f(AgusInside, -1, AgusFront);        
	glTexCoord2f(.65,.78);
        glVertex3f(-AgusInside, -1, AgusFront);
        
// right front quad

	glTexCoord2f(.651, .62);
	glVertex3f(AgusInside,AgusBottom, AgusFront);
	glTexCoord2f(1, .62);
	glVertex3f(AgusOutside,AgusBottom, AgusFront);
	glTexCoord2f(1, .91);	
	glVertex3f(AgusOutside, 1, AgusFront);        
	glTexCoord2f(.651, .91);
        glVertex3f(AgusInside, 1, AgusFront);


// left front quad

	glTexCoord2f(1,.62);
	glVertex3f(-AgusOutside,AgusBottom, AgusBack);
	glTexCoord2f(.651,.62);
	glVertex3f(-AgusInside,AgusBottom, AgusBack);
	glTexCoord2f(.651,.91);	
	glVertex3f(-AgusInside, 1, AgusBack);        
	glTexCoord2f(1,.91);
        glVertex3f(-AgusOutside, 1, AgusBack);
        
// middle front quad

	glTexCoord2f(.65,.62);
	glVertex3f(-AgusInside, AgusBottom, AgusBack);
	glTexCoord2f(.35,.62);
	glVertex3f(AgusInside, AgusBottom, AgusBack);
	glTexCoord2f(.35,.78);	
	glVertex3f(AgusInside, -1, AgusBack);        
	glTexCoord2f(.65,.78);
        glVertex3f(-AgusInside, -1, AgusBack);
        
// right front quad

	glTexCoord2f(.651, .62);
	glVertex3f(AgusInside,AgusBottom, AgusBack);
	glTexCoord2f(1, .62);
	glVertex3f(AgusOutside,AgusBottom, AgusBack);
	glTexCoord2f(1, .91);	
	glVertex3f(AgusOutside, 1, AgusBack);        
	glTexCoord2f(.651, .91);
        glVertex3f(AgusInside, 1, AgusBack);
	
 
// middle roof quad

	glTexCoord2f(.6, .58);
	glVertex3f(-AgusInside, -1, AgusBack);
	glTexCoord2f(.6, 0);
	glVertex3f(-AgusInside, -1, AgusFront);
	glTexCoord2f(.35, 0);	
	glVertex3f(AgusInside, -1, AgusFront);        
	glTexCoord2f(.35, .58);
        glVertex3f(AgusInside, -1, AgusBack);
	
               
        Agus2Sides (-AgusOutside) ;
        Agus2Sides (AgusOutside) ;
        Agus2Sides (-AgusInside) ;
        Agus2Sides (AgusInside) ;
        
        
// left left roof        
	glTexCoord2f(.6, 0);
	glVertex3f(-AgusOutside, 1, AgusFront);
	glTexCoord2f(.6, .58);
	glVertex3f(-AgusOutside, 1, AgusBack);
	glTexCoord2f(.35, .58);	
	glVertex3f(-AgusOutside + ((AgusOutside-AgusInside)/2), 3, AgusBack);        
	glTexCoord2f(.35, 0);
	glVertex3f(-AgusOutside + ((AgusOutside-AgusInside)/2), 3, AgusFront);
        
// left right roof        
	glTexCoord2f(.6, .58);
        glVertex3f(-AgusOutside + ((AgusOutside-AgusInside)/2), 3, AgusBack);        
	glTexCoord2f(.6, 0);
	glVertex3f(-AgusOutside + ((AgusOutside-AgusInside)/2), 3, AgusFront);
	glTexCoord2f(.35, 0);
	glVertex3f(-AgusInside, 1, AgusFront);
	glTexCoord2f(.35, .58);	
	glVertex3f(-AgusInside, 1, AgusBack);


// right left roof        
	glTexCoord2f(.6, 0);
	glVertex3f(AgusInside, 1, AgusFront);
	glTexCoord2f(.6, .58);
	glVertex3f(AgusInside, 1, AgusBack);
	glTexCoord2f(.35, .58);	
	glVertex3f(AgusInside + ((AgusOutside-AgusInside)/2), 3, AgusBack);        
	glTexCoord2f(.35, 0);
	glVertex3f(AgusInside + ((AgusOutside-AgusInside)/2), 3, AgusFront);
        
// right right roof        
	glTexCoord2f(.6, .58);
        glVertex3f(AgusInside + ((AgusOutside-AgusInside)/2), 3, AgusBack);        
	glTexCoord2f(.6, 0);
	glVertex3f(AgusInside + ((AgusOutside-AgusInside)/2), 3, AgusFront);
	glTexCoord2f(.35, 0);
	glVertex3f(AgusOutside, 1, AgusFront);
	glTexCoord2f(.35, .58);	
	glVertex3f(AgusOutside, 1, AgusBack);


	glEnd();



	glBegin(GL_TRIANGLES) ;

        Agus2Roofs(5) ;
        Agus2Roofs(-5) ;



	glEnd();

 	
        Agus2Texture.deactivate() ;

}



//*************************************************
//       Make Agus 3 Building
//*************************************************

void makeAgus3House(int i, int j) {

float Agus3FirstFlEdge = 9.5;
float Agus3edge = 9.1; 
int Agus3FirstFlTop = 1; 
int Agus3Top = 13 ;
float ffTL = 1 ;
float ffTR = .2264 ;
float ffTT = .702 ;
float ffTB = .55 ;
float tfTT = 1 ;
float tfTL = .984 ;
float tfTR = .239 ;

int sffTL = 1 ;
float sffTT = .19 ;
float sffTR = .50 ;
int sffTB = 0 ;
float stfTT = .53 ;
float stfTL = .984 ;
float stfTR = .53 ;

float cL = .508 ;
float cR = 0 ;
float cT = .27 ;
float cB = 0 ;


        // figure out some jitter
        int jitter = 4 - (((i*j)^2)%10);
        glTranslatef(((i*xplot)+jitter),0,((j*zplot)+jitter));
        float heightScale = 1.0 + .1*(((i*j)^2)%5) ;
        glScalef(1.0,heightScale,1.0);

        Agus3Texture.activate() ;

	glBegin(GL_QUADS) ;

// First floor
	// B A
	// C D

	glTexCoord2f(ffTL,ffTT);
	glVertex3f(Agus3FirstFlEdge,Agus3FirstFlTop,Agus3FirstFlEdge);
	glTexCoord2f(ffTR,ffTT);
	glVertex3f(-Agus3FirstFlEdge,Agus3FirstFlTop,Agus3FirstFlEdge);
	glTexCoord2f(ffTR,ffTB);	
	glVertex3f(-Agus3FirstFlEdge,bldBottom,Agus3FirstFlEdge);
	glTexCoord2f(ffTL,ffTB);
        glVertex3f(Agus3FirstFlEdge,bldBottom,Agus3FirstFlEdge);
        
	
        // D A
	// C B
	glTexCoord2f(ffTL,ffTT);
	glVertex3f(Agus3FirstFlEdge,Agus3FirstFlTop,-Agus3FirstFlEdge);
	glTexCoord2f(ffTL,ffTB);
	glVertex3f(Agus3FirstFlEdge,bldBottom,-Agus3FirstFlEdge);
        glTexCoord2f(ffTR,ffTB);
	glVertex3f(-Agus3FirstFlEdge,bldBottom,-Agus3FirstFlEdge);
	glTexCoord2f(ffTR,ffTT);
        glVertex3f(-Agus3FirstFlEdge,Agus3FirstFlTop,-Agus3FirstFlEdge);
        
	// side panels

	glTexCoord2f(sffTL,sffTT);
	glVertex3f(-Agus3FirstFlEdge,Agus3FirstFlTop,Agus3FirstFlEdge);
	glTexCoord2f(sffTR,sffTT);
	glVertex3f(-Agus3FirstFlEdge,Agus3FirstFlTop,-Agus3FirstFlEdge);
	glTexCoord2f(sffTR,sffTB);
	glVertex3f(-Agus3FirstFlEdge,bldBottom,-Agus3FirstFlEdge);
	glTexCoord2f(sffTL,sffTB);
	glVertex3f(-Agus3FirstFlEdge,bldBottom,Agus3FirstFlEdge);
	glTexCoord2f(sffTR,sffTB);
	glVertex3f(Agus3FirstFlEdge,bldBottom,Agus3FirstFlEdge);
	glTexCoord2f(sffTL,sffTB);
	glVertex3f(Agus3FirstFlEdge,bldBottom,-Agus3FirstFlEdge);
	glTexCoord2f(sffTL,sffTT);
	glVertex3f(Agus3FirstFlEdge,Agus3FirstFlTop,-Agus3FirstFlEdge);
	glTexCoord2f(sffTR,sffTT);
	glVertex3f(Agus3FirstFlEdge,Agus3FirstFlTop,Agus3FirstFlEdge);


// Second Floor
	// B A
	// C D

	glTexCoord2f(tfTR,tfTT);
	glVertex3f(Agus3edge,Agus3Top,Agus3edge);
	glTexCoord2f(tfTL,tfTT);
	glVertex3f(-Agus3edge,Agus3Top,Agus3edge);
	glTexCoord2f(tfTL,ffTT);	
	glVertex3f(-Agus3edge,Agus3FirstFlTop,Agus3edge);
	glTexCoord2f(tfTR,ffTT);
        glVertex3f(Agus3edge,Agus3FirstFlTop,Agus3edge);
        
	
        // D A
	// C B
	glTexCoord2f(tfTR,tfTT);
	glVertex3f(Agus3edge,Agus3Top,-Agus3edge);
	glTexCoord2f(tfTR,ffTT);
	glVertex3f(Agus3edge,Agus3FirstFlTop,-Agus3edge);
        glTexCoord2f(tfTL,ffTT);
	glVertex3f(-Agus3edge,Agus3FirstFlTop,-Agus3edge);
	glTexCoord2f(tfTL,tfTT);
        glVertex3f(-Agus3edge,Agus3Top,-Agus3edge);
        
	// side panels

	glTexCoord2f(stfTR,stfTT);
	glVertex3f(-Agus3edge,Agus3Top,Agus3edge);
	glTexCoord2f(stfTL,stfTT);
	glVertex3f(-Agus3edge,Agus3Top,-Agus3edge);
	glTexCoord2f(stfTL,sffTT);
	glVertex3f(-Agus3edge,Agus3FirstFlTop,-Agus3edge);
	glTexCoord2f(stfTR,sffTT);
	glVertex3f(-Agus3edge,Agus3FirstFlTop,Agus3edge);
	glTexCoord2f(stfTL,sffTT);
	glVertex3f(Agus3edge,Agus3FirstFlTop,Agus3edge);
	glTexCoord2f(stfTR,sffTT);
	glVertex3f(Agus3edge,Agus3FirstFlTop,-Agus3edge);
	glTexCoord2f(stfTR,stfTT);
	glVertex3f(Agus3edge,Agus3Top,-Agus3edge);
	glTexCoord2f(stfTL,stfTT);
	glVertex3f(Agus3edge,Agus3Top,Agus3edge);


	// rooftops
        // first floor
//      	glColor3f(.3,.3,.3) ;

	glTexCoord2f(cL, cT);
        glVertex3f(-Agus3FirstFlEdge,Agus3FirstFlTop,-Agus3FirstFlEdge);
        glTexCoord2f(cR, cT);
        glVertex3f(-Agus3FirstFlEdge,Agus3FirstFlTop,Agus3FirstFlEdge);
	glTexCoord2f(cR,cB);
        glVertex3f(Agus3FirstFlEdge,Agus3FirstFlTop,Agus3FirstFlEdge);
	glTexCoord2f(cL,cB);
        glVertex3f(Agus3FirstFlEdge,Agus3FirstFlTop,-Agus3FirstFlEdge);
        

        // second floor
//      	glColor3f(.3,.3,.3) ;

	glTexCoord2f(cL, cT);
        glVertex3f(-Agus3edge,Agus3Top,-Agus3edge);
        glTexCoord2f(cR, cT);
        glVertex3f(-Agus3edge,Agus3Top,Agus3edge);
	glTexCoord2f(cR,cB);
        glVertex3f(Agus3edge,Agus3Top,Agus3edge);
	glTexCoord2f(cL,cB);
    	glVertex3f(Agus3edge,Agus3Top,-Agus3edge);

	glEnd();

        Agus3Texture.deactivate() ;



}




//*************************************************
//       Make Big Sky
//*************************************************

void makeBigSky() {	

    glColor3f(.8,.9,1) ;

	glTranslatef(headX, 0, headZ);
        
// add something in for if we're at the end of the earth, put the box there..


	int k = 200 ; // multiplier for how far away box is from our head
//	int k = m ; 

    (mySkySide)->activate() ;
	
	glBegin(GL_QUADS) ;
	glColor3f(.6,.8,1) ;

	glTexCoord2f(0,0);
	glVertex3f(-xplot*k,-1,-zplot*k);
	glTexCoord2f(0,1);
	glVertex3f(-xplot*k,7000,-zplot*k);
	glTexCoord2f(1,1);
	glVertex3f(xplot*k,7000,-zplot*k);
	glTexCoord2f(1,0);
	glVertex3f(xplot*k,-1,-zplot*k);

	glTexCoord2f(0,0);
	glVertex3f(-xplot*k,-1, zplot*k);
	glTexCoord2f(0,1);
	glVertex3f(-xplot*k,7000, zplot*k);
	glTexCoord2f(1,1);
	glVertex3f(xplot*k,7000, zplot*k);
	glTexCoord2f(1,0);
	glVertex3f(xplot*k,-1, zplot*k);

	glTexCoord2f(0,0);
	glVertex3f(xplot*k,-1, -zplot*k);
	glTexCoord2f(0,1);
	glVertex3f(xplot*k,7000, -zplot*k);
	glTexCoord2f(1,1);
	glVertex3f(xplot*k,7000, zplot*k);
	glTexCoord2f(1,0);
	glVertex3f(xplot*k,-1, zplot*k);


	glTexCoord2f(0,0);
	glVertex3f(-xplot*k,-1, -zplot*k);
	glTexCoord2f(1,0);
	glVertex3f(-xplot*k,7000, -zplot*k);
	glTexCoord2f(1,1);
	glVertex3f(-xplot*k,7000, zplot*k);
	glTexCoord2f(0,1);
	glVertex3f(-xplot*k,-1, zplot*k);


	glEnd();


    (mySkySide)->deactivate() ;
                
    (mySkyTop)->activate() ;

	glBegin(GL_QUADS) ;
        
        glTexCoord2f(0,0);
	glVertex3f(-xplot*k,7000, -zplot*k);
	glTexCoord2f(1,0);
	glVertex3f(xplot*k,7000, -zplot*k);
	glTexCoord2f(1,1);
	glVertex3f(xplot*k,7000, zplot*k);
	glTexCoord2f(0,1);
	glVertex3f(-xplot*k,7000, zplot*k);
        
	glEnd();

    (mySkyTop)->deactivate() ;


//	(myGrass)->activate() ;
	
	glBegin(GL_QUADS) ;  // this makes a flat green plane. 
    
	glColor3f(0,.5,.1) ;
	glVertex3f(-xplot*k,-10, -zplot*k);
	glVertex3f(xplot*k,-10, -zplot*k);
	glVertex3f(xplot*k,-10, zplot*k);
	glVertex3f(-xplot*k,-10, zplot*k);
        
	glEnd();
//	(myGrass)->deactivate() ;



}

//*************************************************
//       Make Water
//*************************************************

void makeWater(int i, int j) {

        glColor3f(.2,.2,1);
        glTranslatef(i*xplot,0,j*zplot);


	glBegin(GL_QUADS) ;
	glColor3f(.1,.1,.8) ;

	glVertex3f(xplot/2,-4,zplot/2);
	glVertex3f(xplot/2,-4,-zplot/2);
	glVertex3f(-xplot/2,-4,-zplot/2);
	glVertex3f(-xplot/2,-4,zplot/2);

	glEnd();

}



//*************************************************

//       Make Road

//*************************************************

void makeRoad(int i, int j) {

        if (timeOfDay == '8') {
        glColor3f(.4,.4,.4); 
        } else {
        glColor3f(.1,.1,.1); }
        
        
        glTranslatef(i*xplot,0,j*zplot);

	asphaltTexture.activate() ;
        glBegin(GL_QUADS) ;

//	glColor3f(.2,.2,.2) ;
	glTexCoord2f(0,0);
	glVertex3f(xplot/2,-4,zplot/2);

	glTexCoord2f(1,0);
	glVertex3f(xplot/2,-4,-zplot/2);

	glTexCoord2f(1,1);
	glVertex3f(-xplot/2,-4,-zplot/2);

	glTexCoord2f(0,1);
	glVertex3f(-xplot/2,-4,zplot/2);

	glEnd();	
	asphaltTexture.deactivate();
}


void makeAFlatGreyPlane() {
	glColor3f(.3, .3, .3);
	glBegin(GL_QUADS) ;

	glTexCoord2f(0,0);
	glVertex3f(0,-5,0);

	glTexCoord2f(0,1);
	glVertex3f(0,-5,zplot*num_rows);

	glTexCoord2f(1,1);
	glVertex3f(xplot*num_cols,-5,zplot*num_rows);

	glTexCoord2f(1,0);
	glVertex3f(xplot*num_cols,-5,0);

	glEnd();
}

//*************************************************
//       Make Low Cloud Ceiling
//*************************************************

void makeLowCloudCeiling() {

    cloudsTexture.activate();

    glBegin(GL_QUADS) ;
    glColor4f(0, .8, .4, 1);

    glTexCoord2f(0,0);
    glVertex3f(0,CEILING,0);

    glTexCoord2f(0,1);
    glVertex3f(0,CEILING,zplot*num_rows);

    glTexCoord2f(1,1);
    glVertex3f(xplot*num_cols,CEILING,zplot*num_rows);

    glTexCoord2f(1,0);
    glVertex3f(xplot*num_cols,CEILING,0);

    glEnd();
    cloudsTexture.deactivate();


/*	glBegin(GL_QUADS) ;
    glColor4f(1, 0, 0, .4);

    glTexCoord2f(0,0);
    glVertex3f(0,CEILING-1,0);

    glTexCoord2f(0,1);
    glVertex3f(0,CEILING-1,zplot*num_rows);

    glTexCoord2f(1,1);
    glVertex3f(xplot*num_cols,CEILING-1,zplot*num_rows);

    glTexCoord2f(1,0);
    glVertex3f(xplot*num_cols,CEILING-1,0);

    glEnd();
*/
}

//*************************************************
//       Make Big Grass
//*************************************************

void makeBigGrass() {	

	myGrass->activate();
        
	glBegin(GL_QUADS) ;
	glColor3f(0, .8, .4);

	glTexCoord2f(0,0);
	glVertex3f(0,-5,0);

	glTexCoord2f(0,1);
	glVertex3f(0,-5,zplot*num_rows);

	glTexCoord2f(1,1);
	glVertex3f(xplot*num_cols,-5,zplot*num_rows);

	glTexCoord2f(1,0);
	glVertex3f(xplot*num_cols,-5,0);

	glEnd();
    myGrass->deactivate();


}


//*************************************************
//       Make A Tile
//*************************************************

void makeATile(int i, int j, int myHeight) {	

    glTranslatef(i*xplot,0,j*zplot);

	glBegin(GL_QUADS) ;

	glVertex3f(xplot/3,myHeight,zplot/3);
	glVertex3f(xplot/3,myHeight,-zplot/3);
	glVertex3f(-xplot/3,myHeight,-zplot/3);
	glVertex3f(-xplot/3,myHeight,zplot/3);

	glEnd();

}

//*************************************************
//       Make A Tile
//*************************************************

void makeATile(int i, int j, int myHeight, float width) {

    glTranslatef(i*xplot,0,j*zplot);

    glBegin(GL_QUADS) ;

    glVertex3f(width*(xplot),myHeight,width*zplot);
    glVertex3f(width*xplot,myHeight,width*(-zplot));
    glVertex3f(-xplot*width,myHeight,width*(-zplot));
    glVertex3f(-xplot*width,myHeight,width*(zplot));

    glEnd();

}

//*************************************************
//       Make A Ground Light
//*************************************************

void makeAGroundLight(int i, int j) {	

	int myHeight = -4 ;

    glTranslatef(i*xplot,0,j*zplot);

	glutSolidCube(5.0);

}


//*************************************************
//       Make Debugging Grid
//*************************************************

void makeDebuggingGrid() {	

        
	glBegin(GL_QUADS) ;

	glColor3f(1.0, 0, 0);
	glVertex3f(0,-10,0);
	glVertex3f(0,-10,zplot*2000);
	glVertex3f(xplot*2000,-10,zplot*2000);
	glVertex3f(xplot*2000,-10,0);

	glColor3f(0, 1.0, 0);
	glVertex3f(xplot*4000,-10,zplot*4000);
	glVertex3f(xplot*4000,-10,zplot*2000);
	glVertex3f(xplot*2000,-10,zplot*2000);
	glVertex3f(xplot*2000,-10,zplot*4000);
	
	glColor3f(0, 0, 1.0);
	glVertex3f(xplot*2000,-10,zplot*4000);
	glVertex3f(xplot*2000,-10,zplot*2000);
	glVertex3f(0,-10,zplot*2000);
	glVertex3f(0,-10,zplot*4000);
	
	glColor3f(1.0, 1.0, 0);
	glVertex3f(xplot*4000,-10,0);
	glVertex3f(xplot*4000,-10,zplot*2000);
	glVertex3f(xplot*2000,-10,zplot*2000);
	glVertex3f(xplot*2000,-10,0);

	glEnd();


}
