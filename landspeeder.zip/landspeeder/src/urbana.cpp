/*
 *  urbana.cpp
 *  
 *
 *  Created by rose marshack on Thu Feb 26 2003.
 *
 */ 
 
#include "arPrecompiled.h"
#include "stdio.h"
#include "stdlib.h" // just for random number generator

#include "arMasterSlaveFramework.h"
//#include "arTexture.h"

#include "math.h"
#include "arMath.h"

// for reading in a file

#pragma warning(disable : 4786) //For VC++ compiler
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
 
#include "landspeeder.h"

extern vector<double> myHouseDataVector;

extern double startLat ; 
extern arTexture urbanaHouseTexture[8] ;
extern int myTexture ;
extern double startLat ;
extern double startLongit ;
extern arTexture asphaltTexture ;

float multiplier = 100000 ;


House::House(double myLat, double myLong, int myHouseType, int myTexture, int myX, int myY, int myZ, int myRoofHeight)  // 
 {
latitude = myLat ;
longitude = myLong ;
houseType = myHouseType ;
textureType = myTexture ;
roofHeight = myRoofHeight ;
x = myX ; y = myY ; z = myZ ;

} ;


House::~House()
{
cout << "House Destructor Called" << endl ;
} ;
        
void House::printHouse()
{
	glPushMatrix();
//  	glColor3f(colorR, colorG, colorB);  // 		
//        glTranslatef(currentPos[0],currentPos[1],currentPos[2]);

	glPopMatrix();
  
} ;


// allocate space for number_of_roads amount of cars
vector<House*> h1;


//*****************************************************

// Make Urbana Houses
// vector format is lat, long, texture

//*****************************************************

    
void House::makeUrbanaHouse() {

// here's what we need to build a house. x, y, z are 1/2 length, height, width. roofHeight is from ground.
// so format of file should be:
// lat, longit, houseType, texture, x, y, z, roofheight   
        arTexture *myHouseTexture ;
        arTexture* saveTexture = myHouseTexture ;
        
        myHouseTexture = &urbanaHouseTexture[0];
        
        multiplier = 100000 ;
        
        double adjustedLatitude = (latitude - startLat)*multiplier ;
        double adjustedLongitude = (longitude - startLongit)*multiplier ;
//        cout << "adjusted lat/long = "<< adjustedLatitude << ", " << adjustedLongitude << endl ;
        
        glTranslatef(adjustedLatitude, 0, adjustedLongitude);
//        glScalef(20, 20, 20) ;
        
//	glColor3f(1.0, 0, 0);
//                glutSolidCube(10.0) ;
 //       cout << "texture type = "<< textureType << endl ;
        
        (myHouseTexture+textureType)->activate() ;

	glBegin(GL_QUADS) ;

	glTexCoord2f(.5,.8);
	glVertex3f(x,y,z);
	glTexCoord2f(1,.8);
	glVertex3f(-x,y,z);

	glTexCoord2f(1,.5);	
	glVertex3f(-x,-y,z);
        
	glTexCoord2f(.5,.5);
        glVertex3f(x,-y,z);
        
	
        // A D
	// B C
	glTexCoord2f(0,.5);
	glVertex3f(x,y,-z);

	glTexCoord2f(0,0);
	glVertex3f(x,-y,-z);

        glTexCoord2f(.5,0);
	glVertex3f(-x,-y,-z);

	glTexCoord2f(.5,.5);
        glVertex3f(-x,y,-z);
        
	// side panels

	glTexCoord2f(.5,.5);
	glVertex3f(-x,y,z);

	glTexCoord2f(1,.5);
	glVertex3f(-x,y,-z);
    
	glTexCoord2f(1,0);
	glVertex3f(-x,-y,-z);
    
	glTexCoord2f(.5,0);
	glVertex3f(-x,-y,z);

	glTexCoord2f(.5,0);
	glVertex3f(x,-y,z);
	glTexCoord2f(1,0);
	glVertex3f(x,-y,-z);
	glTexCoord2f(1,.5);
	glVertex3f(x,y,-z);

	glTexCoord2f(.5,.5);
	glVertex3f(x,y,z);

	// rooftops
//	glColor3f(.1,.1,.4);

	//  C D
	//	B A
	glTexCoord2f(.5,.5);
	glVertex3f(x+1,y,z+1);

	glTexCoord2f(0,.5);
	glVertex3f((x+1),y,-(z+1));

	glTexCoord2f(0,1);
	glVertex3f(0,roofHeight,-(z+1));
        glTexCoord2f(.5,1);
	glVertex3f(0,roofHeight,(z+1));

	glTexCoord2f(.5,.5);
	glVertex3f(-(x+1),y,(z+1));

	glTexCoord2f(0,.5);
	glVertex3f(0,roofHeight,(z+1));
        glTexCoord2f(0,1);
        glVertex3f(0,roofHeight,-(z+1));
	
	glTexCoord2f(.5,1);
	glVertex3f(-(x+1),y,-z);
	glEnd(); 

	glBegin(GL_TRIANGLES) ;

        glTexCoord2f(1,.80);
	glVertex3f(-(x+1),y,z);

	glTexCoord2f(.75,1);
	glVertex3f(0,roofHeight,z);

	glTexCoord2f(.5,.81);
	glVertex3f((x+1),y,z);

	glTexCoord2f(1,.80);
	glVertex3f(-(x+1),y,-z);

	glTexCoord2f(.75,1);
	glVertex3f(0,roofHeight,-z);

	glTexCoord2f(.5,.81);
	glVertex3f((x+1),y,-z);

	glEnd();

        
       (myHouseTexture+textureType)->deactivate() ;
       myHouseTexture = saveTexture ;


}


void makeUrbanaRoads() {

/* -88.21931	40.10444
-88.21778	40.10445
-88.21778	40.10356
-88.21928	40.10355
*/
float uroads[8] = {-88.21931, 40.10444, -88.21778, 40.10445, -88.21778, 40.10356, -88.21928, 40.10355} ;

       glColor3f(.4,.4,.4); 
        
        
        float topX1 = (-88.21778 - startLat) * multiplier ;
        float topY1 =  (40.10445 - startLongit) * multiplier ;
        float botX1 = (-88.21778 - startLat) * multiplier ;
        float botY1 = (40.10356 - startLongit) * multiplier ;
        
        float roadWidth = 8 ;
        
        
//        glTranslatef(i*xplot,0,j*zplot);

	asphaltTexture.activate() ;
        glBegin(GL_QUADS) ;
        glColor3f(.2, .2, .2) ;
        
  	glVertex3f(topX1- roadWidth ,-4, topY1 + roadWidth );
	glVertex3f(topX1 + roadWidth ,-4, topY1 + roadWidth);
	glVertex3f(botX1 + roadWidth ,-4,botY1 - roadWidth);
	glVertex3f(botX1 - roadWidth ,-4,botY1 - roadWidth);
                                                
        for (int g = 0; g < 6; g=g+2){
        topX1 = (uroads[g]- startLat) * multiplier ; 
        topY1 = (uroads[g+1]- startLongit) * multiplier  ;
        botX1 = (uroads[g+2]- startLat) * multiplier ; 
        botY1 = (uroads[g+3] - startLongit) * multiplier;
        
        
//	glTexCoord2f(0,0);
	glVertex3f(topX1 ,-4, topY1- roadWidth );

//	glTexCoord2f(1,0);
	glVertex3f(topX1 ,-4, topY1 + roadWidth);

//	glTexCoord2f(1,1);
	glVertex3f(botX1  ,-4,botY1+ roadWidth);

//	glTexCoord2f(0,1);
	glVertex3f(botX1  ,-4,botY1- roadWidth);
        }

	glEnd();	
	asphaltTexture.deactivate();
}


//*****************************************************

// Display Urbana Houses

//*****************************************************
void displayUrbana ()
{
  glPushMatrix() ;
 glTranslatef(500,0,500);
 
        for (int i = 0; i < h1.size(); i++) {
               glPushMatrix() ;
                h1[i]->makeUrbanaHouse() ; 
                glPopMatrix() ;
                
            } ;
            
            makeUrbanaRoads() ;
            
  glPopMatrix() ;


}
