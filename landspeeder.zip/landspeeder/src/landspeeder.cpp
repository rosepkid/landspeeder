#include "arPrecompiled.h"
#include "arDistSceneGraphFramework.h"
#include "stdio.h"
#include "stdlib.h" // just for random number generator

#include "arMasterSlaveFramework.h"


#include "math.h"
#include "arMath.h"
#include "arSoundAPI.h"

#include "landspeeder.h"

#include <sstream>

#pragma warning(disable : 4786) //For VC++ compiler
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>


int LIGHTMAP = 0 ; // assume we're not making the "lightmap" program
int CLASSIC = 0 ; // assume we're not in "classic" mode
int URBANA = 0 ; // 1 means we're displaying Urbana, not the normal databases.

int** array01 ;
int** array02 ;
int** array03 ;
int** array04 ;
int** array05 ;
int** array06 ;
int** array07 ;
int** array08 ;
int** array09 ;
int** array10 ;


//char** randomArray ;
int*** whatDataBasePtr ; 

//int array3[10][MAX_COLUMNS][MAX_ROWS];

extern double* RoadArray;
extern double** RoadTessArray;
extern GLdouble** LakeArray;
extern double* PolyRoadsArray;

extern vector<int> myRoadDataVector;

double frameTime ;

double smallestX;
double smallestY;
int NODATA_value;
int total_num_cols = 0;
int total_num_rows = 0;

float WaterArray[4][4];

int num_cols = 0;
int num_rows = 0;
int rows_to_display = 101 ;
int cols_to_display = 101 ;

int number_of_road_nodes = 0 ;
int number_of_lake_nodes = 0 ;
int number_of_polyroad_nodes = 0;
int totalNumCarsCloseBy = 0 ;
int carsToHear = 0 ;

arVector3 headPositionInWorld ;

int xplot = 30; // this is how big each plot of land is
int zplot = 30;

// for FOG
GLfloat fogColor[4]= {0.8f, 0.8f, 0.8f, 1.0f};		// Fog Color


//char randomArray[MAX_COLUMNS][MAX_ROWS];	// generate a random array for texture and jitter
						// this corresponds to the regular array of houses.
float headX; 
float headY;
float headZ;

int soundDebugX = 0 ;

char whatDataBase = '1' ; //gets set through console input or Buttons -- at this point should be 1 or 2.
char whatHouses = '5' ; // set through console input or Buttons 5=realistic texures, 6=cartoon textures
char timeOfDay = '8' ; //set through console input or Buttons 8 = daytime, 9 = nighttime

float getAngleFromPosition(float x1, float x2, float y1, float y2) ;

int carNumber = 0 ;

string dataPath; 
arMasterSlaveFramework* framework;
arVector3 place;
// timeStamp;

int overhereSoundTransformID ;

extern void makeRes(int i, int j) ;
extern void makeHouse(char temp) ;
extern void makeAgus1House(int i, int j) ;
extern void makeAgus2House(int i, int j) ;
extern void makeAgus3House(int i, int j) ;
extern void makeAgusResidential(int i, int j) ;
extern void makeBld(int i, int j) ;
extern void makeBigHouse(char temp) ;
extern void makeBigGrass() ;
extern void makeAFlatGreyPlane() ;
extern void makeBigSky() ;
extern void makeLowCloudCeiling() ;
//extern void makeFog() ;
//extern void initFog() ;
extern void makeWater(int i, int j) ;
extern void makeTree(int i, int j) ;
extern void makeRoad(int i, int j) ;
extern void makeTerrain() ;
extern void makeDebuggingGrid() ;
extern void makeRandomArray() ;
extern void makeATile(int i, int j, int height) ;
extern void makeATile(int i, int j, int height, float width) ;
extern void makeAGroundLight(int i, int j) ;
extern void doTrees(int i, int j) ;

extern int** readFile(string theFile) ;
extern GLdouble** readTesselFile(string theFile, int &z, float y, int r, int s) ;
extern int readDataFile(string theFile, double** m, int &z) ;
extern int readHouseDataFile(string theFile) ;
extern int readInit(float &x, float &y, float &z) ;

extern arTexture *myGrass ;
extern arTexture *mySkyTop ;
extern arTexture skyTexture ;
extern arTexture bldTexture[] ;
extern void makeCar(float R, float G, float B) ;
extern void makeTruck(float R, float G, float B) ;

extern void readSomeTextures();
extern void figureOutTextures();

extern void letterbox(string aString, float x, float y, float z) ;
extern void letterbox1(string aString, float x, float y, float z) ;

extern void initLighting() ;

void displayLines() ;
void displayDebugRoads() ;
void displayWater(GLUtesselator* tObj) ;
void displayPolyRoads() ;
void makeWheels(float Angle, float transForm);

// pointers to functions
void (*myFunctionPtr) (int, int, int);
void (*drawRoutinePtr) (int, int) ;  



// for car positions (shared stuff)
float c1Positions[6000] ; // space for x/z/theta coordinates of 2000 cars
float c2Positions[6000] ;

 

// tesselation stuff
GLUtriangulatorObj *tObj = NULL;
GLdouble *vertex_data[4] ;
GLuint startList ;

// For the buttons !!! 
GLint but1, but2, but3;
GLint but1wasPressed = 0, but2wasPressed = 0, but3wasPressed = 0; // true if button was pressed and not released
GLint but4, but5, but6;
GLint but4wasPressed = 0, but5wasPressed = 0, but6wasPressed = 0; // true if button was pressed and not released

// for the Time Steps, traffic, reloading
char PLAYTIMESTEPS = 0 ;
char MORETRAFFIC = 0 ;
char RELOADINIT = 0 ;

extern void createVectorArray() ;
extern void displayUrbana() ;


// For Sound
int transformID = 0 ;

int transformID1 = 0 ;
int objectID = 0 ;

int objectIDArray[10] ;
int objectIDArrayB[10] ;
float noiseAmp ;

int carProximityArray[10];  // stores the indices into the car vector of close cars.
int soundArray[10]; // same

int carProximityArrayB[10];  // stores the indices into the car vector of close cars.
int soundArrayB[10]; // same

extern void setCarSounds() ;
extern void calculateCarNoises(vector<Car*> c, int* arg, int* arg1, int* objectIDArray) ;

//int objectID1 = 0 ;

// Cars

void makeWheel()
{   
        GLint wheelRadius = .53;
        GLint nsides = 10;
        GLint nrings = 5;
//        glRotatef(90, 0,1,0);
        glutSolidTorus(.267, wheelRadius, nsides, nrings);
//        glutSolidSphere(wheelRadius, sli, sta );
} ;

Road::Road(int SegNum, int NumCars) {
    numberOfCarsOnRoad = NumCars ;
    segmentNumber = SegNum ;

} ;

Road::~Road()
{
    cout << "Road Destructor Called" << endl ;
} ;

RandomPod::RandomPod() 
{
	jitterX = 4-rand()%10;
	jitterY = 4-rand()%10;
	texture = rand()%7; // 0-2 are small houses, 3-6 are large ones
	heightScale = 1+.1*(rand()%5);
//        widthScale = 

} ;

RandomPod::~RandomPod()
{
} ;


Car::Car(int i, float y, bool forwards)  // i indexes into RoadArray, y is height for positioning
 {
    
static int numberCounter = 0 ;
colorR = 0;
colorG = 0;
colorB = 0;
//velocity = 1+rand()%5 ; //2+rand()%8 ;

// is it a truck or a car?
/*isATruck = 0 ;
if ((rand()%8)>= 7) {
    isATruck = 1 ; 
} ;
*/

//arMatrix4 soundMatrixPos = ar_translationMatrix(currentPos[0],currentPos[1],currentPos[2]);
//cout << "forward = " << forwards << endl ;

if (forwards) {
//    cout << "making a forwards car " << endl ;
    currentPos = arVector3(RoadArray[i], y, RoadArray[i+1]);
    prevNode = arVector3(RoadArray[i], y, RoadArray[i+1]);
    nextNode = arVector3(RoadArray[i+2], y, RoadArray[i+3]);
    beginPos = arVector3(RoadArray[i], y, RoadArray[i+1]);
    endPos = arVector3(RoadArray[i+2], y, RoadArray[i+3]);
    beginArrayIndex = i ;
    endArrayIndex = i+2 ;
    currentArrayIndex = i ;
} else {
//    cout << "making a backwards car " << endl ;
    currentPos = arVector3(RoadArray[i+2], y, RoadArray[i+3]);
    prevNode = arVector3(RoadArray[i+2], y, RoadArray[i+3]);
    nextNode = arVector3(RoadArray[i], y, RoadArray[i+1]);
    beginPos = arVector3(RoadArray[i+2], y, RoadArray[i+3]);
    endPos = arVector3(RoadArray[i], y, RoadArray[i+1]);
    beginArrayIndex = i+2 ;
    endArrayIndex = i ;
    currentArrayIndex = i+2 ;
} ;


colorR = float((rand()%50)/100.0)+.25 ;
colorG = float((rand()%50)/100.0)+.25 ;
colorB = float((rand()%50)/100.0)+.25 ;



} ;


Car::~Car()
{
cout << "Car Destructor Called" << endl ;
} ;
        


void Car::moveCar(float transForm, int angleTransform, int whichCar)
{
    
    GLdouble wheelRadius = 5.0;
    GLint sli = 4; 
    GLint sta = 4;

    float velocity = 1+ whichCar%5 ;
    arVector3 moveAdder ;
//    cout << "nextNode =" << nextNode << " prevNode = " << prevNode << endl ;
//    cout << "endPos = " << endPos << " beginPos = " << beginPos << endl ;

        if ((nextNode[2] - prevNode[2]) > 0) {
            // then we're in the bottom half of the circle
            moveAdder = (velocity*(endPos-beginPos).normalize());
            currentPos = currentPos - moveAdder ; // this moves me forward.
            if ((++(endPos - currentPos)) > (++(beginPos - endPos))) { // we need to start again.
                currentPos =  endPos ;

            } ;//            cout << "moveAdder = " << moveAdder << endl ;
        } else {
//                 cout << "The other moveAdder = " << moveAdder << endl ;
            moveAdder = (velocity*(endPos-beginPos).normalize()) ;
            currentPos = currentPos + moveAdder ; // this moves me forward.
            if ((++(beginPos - currentPos)) > (++(beginPos - endPos))) { // we need to start again.
                currentPos =  beginPos ;

            } ;
        };
 

        float Angle = getAngleFromPosition(nextNode[0], prevNode[0], nextNode[2], prevNode[2]) ;

	// now add the position to the c1Positions array
        whichCar = whichCar*3 ;
	c1Positions[whichCar] = currentPos[0] ;
	c1Positions[whichCar+1] = currentPos[2] ;
	c1Positions[whichCar+2] = Angle+angleTransform ;

} ;

void Car::moveCarBackwards(float transForm, int angleTransform, int whichCar)
{
    
    GLdouble wheelRadius = 5.0;
    GLint sli = 4; 
    GLint sta = 4;
    float velocity = 1+ whichCar%5 ;
    
//    currentPos = currentPos + (velocity*((endPos-beginPos).normalize())/(frameTime/1000.0)) ; // this moves me forward.
    arVector3 moveAdder ;
//    cout << "nextNode =" << nextNode << " prevNode = " << prevNode << endl ;
//    cout << "endPos = " << endPos << " beginPos = " << beginPos << endl ;

        if ((nextNode[2] - prevNode[2]) > 0) {
            // then we're in the bottom half of the circle
            moveAdder = (velocity*(endPos-beginPos).normalize());
            currentPos = currentPos + moveAdder ; // this moves me forward.
            if ((++(beginPos - currentPos)) > (++(beginPos - endPos))) { // we need to start again.
                currentPos =  beginPos ;

            } ;//            cout << "moveAdder = " << moveAdder << endl ;
        } else {
//                 cout << "The other moveAdder = " << moveAdder << endl ;
            moveAdder = (velocity*(endPos-beginPos).normalize()) ;
            currentPos = currentPos - moveAdder ; // this moves me forward.
            if ((++(endPos - currentPos)) > (++(beginPos - endPos))) { // we need to start again.
                currentPos =  endPos ;

            } ;
        };
 
    float y = -4.0 ;


        float Angle = getAngleFromPosition(nextNode[0], prevNode[0], nextNode[2], prevNode[2]) ;

	// now add the position to the c1Positions array
        whichCar = whichCar * 3 ;
	c2Positions[whichCar] = currentPos[0] ;
	c2Positions[whichCar+1] = currentPos[2] ;
	c2Positions[whichCar+2] = Angle+angleTransform ;
	
} ;

void makeWheels(float Angle, float transForm) {

    glColor3f(0,0,0);  // 		
    glRotatef( Angle, 0.0, 1.0, 0.0) ;

    float wheelX = 3.0 ;
    float wheelZ = 1.0 ;

    glPushMatrix();
    glTranslatef(wheelX,0,wheelZ+transForm);
    makeWheel();
    glPopMatrix(); 

    glPushMatrix();
    glTranslatef(wheelX,0,-wheelZ+transForm);
    makeWheel();
    glPopMatrix(); 

    glPushMatrix();
    glTranslatef(-wheelX,0,-wheelZ+transForm);
    makeWheel();
    glPopMatrix(); 

    glPushMatrix();
    glTranslatef(-wheelX,0,wheelZ+transForm);
    makeWheel();
    glPopMatrix(); 
} ;

// allocate space for number_of_roads amount of cars
vector<Car*> c1;
vector<Car*> c2;


// vector<Road*> r1;

float getAngleFromPosition(float x1, float x2, float y1, float y2) {
//    cout << "x1, x2, y1, y2 = "<< x1 << ", " << x2 << ", " << y1 << ", " << y2 << endl ;

    
    if (x1 == x2) { // then slope is infinite
        return (-90) ;
    } else {
        if (y1 == y2) { // then slope is 0
            return (0) ;
        }
        else
        {
            arVector3 A ;
 //           cout << "x2= " << x2 << " x1 = "<<x1 << " y2 = " << y2 << "y1 = " << y1 << endl ;
//            if (((x2 < x1)&&(y2 < y1)) || ((y2 < y1) && (x2 > x1))) {
            if (y2 > y1) {
  //              cout << "newcase" << endl;
               A = arVector3(x1-x2, 0, y1-y2) ; // this is the vector of the road
            } else {
                
             A = arVector3(x2-x1, 0, y2-y1) ; // this is the vector of the road
            } ;
            arVector3 B = arVector3(1, 0, 0) ; // the vector of the car
            A = A/++A ; // normalize the A vector
            
            if (A%B > 0) {
//                cout << "angle is in Q1 or 4" << endl ;
                return (ar_convertToDeg(asin(++(B*A)))) ;
                } else {
//                    cout << "angle is in Q2 or 3" << endl ;
                return (180-(ar_convertToDeg(asin(++(B*A))))) ;
                }
        }	

    }

}


/**************************************************************

	MakeMap - If we're above a certain altitude, just display a
	huge map instead of houses. 
	Run every realtime loop   
	Inputs: None
	Draws: stuff on the stage from array[][]

***************************************************************/
void makeMap(void(*ptr)(int, int, int))
{
int i, j, cellData;

for (j=1; j<total_num_rows; j++) {

	for (i=1; i<total_num_cols; i++) {

		// get the Cell Data from the proper database
		cellData = (*whatDataBasePtr)[i][j];
                
		glPushMatrix();

		// figure out what the object should be; house, water, building, etc.
		switch (cellData) {
		
		case 11: case 12: case 91: case 92:  // this is water
		glColor3f(0,.5,.9);
		//makeAGroundTile(i, j);
		ptr(i, j, -4);
		break;
		
		case 41: case 42: case 43: case 51: case 61: case 71: // it's a tree
		glColor3f(0,.7,.2);
		//makeAGroundTile(i, j);
				ptr(i, j, -4);
		break;

		case 24:  // this is road
		glColor3f(0,0,0);
		//makeAGroundTile(i, j);
				ptr(i, j, -4);
		break;
                               
		// this is commercial
		case 23: 
 		glColor3f(.6,.6,.6);
		//makeAGroundTile(i, j);
				ptr(i, j, -4);
                    
  		break;

		// this is residential
		case 21: case 22:
		glColor3f(.6,.2,.2);
		//makeAGroundTile(i, j);
				ptr(i, j, -4);

                    break; 

		default:
		break;

		}  // end switch

		glPopMatrix();

	} // end for 
	} // end if


}


/**************************************************************

	Do Houses - gets run every realtime loop.       
	Inputs: place where head is, in cells. i.e. I might be at cell (8,8) 
                rowImOn, colImOn

	Draws: stuff on the stage from array[][]

***************************************************************/

void doHouses(int rowImOn, int colImOn)

{	

int i, j, cellData;

int startRow = rowImOn ;
int startCol = colImOn ;

// start your display in the middle of your display area
startRow = startRow - (rows_to_display/2) ;
startCol = startCol - (cols_to_display/2) ;


for (j=startRow; j<(startRow+rows_to_display); j++) {

	for (i=startCol; i<(startCol + cols_to_display); i++) {


		// make sure the indices are in range of the table.
		if ( ((i <= MAX_COLUMNS-1)&&(i >= 0))&&((j <= MAX_ROWS-1) && (j >= 0)))
 	
	{

		// get the Cell Data from the proper database
		cellData = (*whatDataBasePtr)[i][j];
                
		glPushMatrix();

		// figure out what the object should be; house, water, building, etc.
		switch (cellData) {
		
		case 11: case 12: case 91: case 92:  // this is water
		case 24:  // this is road

//                    glColor3f(0,0,0) ;

                break;
                               
		// this is commercial
		case 23:
                    glPushMatrix() ;
                    if (whatHouses == '5') {
                    makeBld(i, j) ; } else { makeAgus3House(i, j); }
                    glPopMatrix() ;
                    
                    // LIGHT Dispersement
 //                   glColor4f(.6,.6,.6, .1) ;
             
		break;

		// this is residential
		case 21: case 22:
                    glPushMatrix() ;
                    if (whatHouses == '5') {
                        makeRes(i, j) ; } else { makeAgusResidential(i, j); }
                    glPopMatrix() ;
                    
                    // LIGHT Dispersement
                  
 //                   glColor4f(.4,.4,.4, .1) ;
                 
                    
                break;


		default:
//                    glColor4f(0,0,0, .1) ;
		break;

		}  // end switch

 /*               if (timeOfDay == '9') {
                    makeATile(i,j,CEILING,.5) ; }
*/
		glPopMatrix();

		} // end for
	} // end for 
	} // end if


}


//*****************************************************
// LIGHT DISPERSEMENT
//*****************************************************
void lightDispersement(int rowImOn, int colImOn)

{	

int i, j, cellData;

float lightAlpha = .2 ;

for (j=1; j<total_num_rows; j++) {

	for (i=1; i<total_num_cols; i++) {

		// get the Cell Data from the proper database
		cellData = (*whatDataBasePtr)[i][j];
                
		glPushMatrix();

		// figure out what the object should be; house, water, building, etc.
		switch (cellData) {
		
		case 11: case 12: case 91: case 92:  // this is water
		case 24:  // this is road

			glColor4f(0,0,0, lightAlpha) ;

        break;
                               
		// this is commercial
		case 23:

			glColor4f(.6,.2,.2, lightAlpha) ;
             
		break;

		// this is residential
		case 21: case 22:
                 
			glColor4f(.4,.0,.0, lightAlpha) ;
                 
                    
        break;


		default:
                    glColor4f(0,0,0, lightAlpha) ;
		break;

		}  // end switch

                if (timeOfDay == '9') {
                    makeATile(i,j,CEILING-1,.5) ; }

		glPopMatrix();

		} // end for
	} // end for 



}





//*****************************************************
// try a tesselator thingy
//*****************************************************

void drawTessSave(GLUtesselator* tObj)
{
	GLdouble outer[4][3] =
	{
		{ 1.0, -1.0, 0.0 } , { 1.0, 1.0, 0.0 } ,
		{-1.0,  1.0, 0.0 } , {-1.0,-1.0, 0.0 }
	};

		const int nHolePts = 20;
	GLdouble hole[nHolePts][3];

	glColor3d(1.0, 0.0, 0.0);

	gluTessBeginPolygon(tObj, NULL);

	gluTessBeginContour(tObj);
	for (int i=0 ; i<4 ; i++)
		gluTessVertex(tObj,outer[i],outer[i]);
	gluTessEndContour(tObj);

	GLdouble r = 0.5;
	GLdouble theta = 0.0;
	GLdouble dTheta = (PI + PI) / nHolePts;

	gluTessBeginContour(tObj);
	// NOTICE: The vertices for the hole must not be overwritten until
	// after control returns from gluTessEndPolygon. That is why they
	// are stored here in successive locations in the "hole" array.
	for (int j=0 ; j<nHolePts ; j++)
	{
		hole[j][0] = r*cos(theta);
		hole[j][1] = r*sin(theta);
		hole[j][2] = 0.0;
		gluTessVertex(tObj,hole[j],hole[j]);
		theta += dTheta;
	}
	gluTessEndContour(tObj);

	gluTessEndPolygon(tObj);
}


void drawTess(GLUtesselator* tObj, void *polygon_data)
{
	GLdouble outer[7][3] =
	{
		{ 1.0, -1.0, 0.0 } , 
		{ 1.0, 1.0, 0.0  } ,
		{-1.0,  1.0, 0.0 } , 
		{-1.0,-1.0, 0.0  } ,
		{0,-2.0, 0.0  },
		{-1.0,-3.0, 0.0  },
		{1.0,-3.0, 0.0  }
	};
		

	glColor3d(.0, 0.0, 1.0);

//	gluTessBeginPolygon(tObj,NULL);
	gluTessBeginPolygon(tObj,NULL);

	gluTessBeginContour(tObj);
	for (int i=0 ; i<7 ; i++) {
//		cout << "i = " << i << ", outer[i]= " << outer[i][0]<<", "<<outer[i][1]<<", "<<outer[i][2] << "\n" ;
		gluTessVertex(tObj,outer[i],outer[i]);
	}
	gluTessEndContour(tObj);

	gluTessEndPolygon(tObj);
}





//*****************************************************

// DO Lakes

// Connect some dots to make lakes.

//*****************************************************
void displayWater(GLUtesselator* tObj)
{
	int i= 0;
	int lakes=0;


//	cout << "number of lake nodes = " << number_of_lake_nodes << "\n" ;

          
        glNewList(startList, GL_COMPILE) ;
//        glShadeModel(GL_FLAT) ;

//	glColor3f(0.0f, 0.4f, 0.6f);

	gluTessBeginPolygon(tObj, NULL);
	gluTessBeginContour(tObj);

	for (i = 0; i< number_of_lake_nodes; i++)
	{
		if (LakeArray[i][0]!=-1) {
//		cout << "i="<<i<<", v = "<< LakeArray[i][0] << ", " << LakeArray[i][1] << ", "<< LakeArray[i][2]   << "\n";
                LakeArray[i][5] = (50+(rand()%50))/100.0  ; // put in a blue value 
		gluTessVertex(tObj, LakeArray[i], LakeArray[i]);
		} else {
		gluTessEndContour(tObj);
		gluTessEndPolygon(tObj);

		gluTessBeginPolygon(tObj, NULL);
		gluTessBeginContour(tObj);
		} ;
	} ;

	gluTessEndContour(tObj);
	gluTessEndPolygon(tObj);
        glEndList();

}


//*****************************************************

// DO Tesselated Roads (this is actually making the green areas that aren't roads)

//*****************************************************
void displayTessRoads(GLUtesselator* tObj)
{
	int i= 0;
	int roads=0;

        glPushMatrix();

      glNewList(startList + 1, GL_COMPILE);


// trying to get a texture here...
        
//	glColor3f(0.0f, 0.5f, 0.15f);

//	cout << "number of road nodes = " << number_of_road_nodes << "\n" ;

	gluTessBeginPolygon(tObj,NULL);
	gluTessBeginContour(tObj);


	for (i = 0; i< number_of_road_nodes; i++)
	{
		if (RoadTessArray[i][0]!=-1) {
//		cout << "i="<<i<<", v = "<< LakeArray[i][0] << ", " << LakeArray[i][1] << ", "<< LakeArray[i][2]   << "\n";
                RoadTessArray[i][3] = .3 ; // (25+(rand()%25))/100.0 ; // make a random green value
                 RoadTessArray[i][4] = .3 ; // (25+(rand()%25))/100.0 ; // make a random green value
                RoadTessArray[i][5] = .3 ; // (25+(rand()%25))/100.0 ; // make a random green value
                RoadTessArray[i][0] = RoadTessArray[i][0] ;
                RoadTessArray[i][2] = RoadTessArray[i][2] ;
                RoadTessArray[i][1] = 15 ;
                
            cout << "tess point at " << RoadTessArray[i][0] << ", " << RoadTessArray[i][2]<< endl ;
            
		gluTessVertex(tObj, RoadTessArray[i], RoadTessArray[i]);
		} else {
		gluTessEndContour(tObj);
		gluTessEndPolygon(tObj);

		gluTessBeginPolygon(tObj,NULL);
		gluTessBeginContour(tObj);
		} ;
	} ;

	gluTessEndContour(tObj);
	gluTessEndPolygon(tObj);
        
                
        glEndList() ;
        glPopMatrix() ;
        
} ;



//*****************************************************
// Make some cars - call from init and also from button-press
void InstantiateCars() {
    int i= 0;
    int j = 0;
    int roadNumber = 0 ;
    int numberToMake = 0;
    
    vector<Car*>::iterator iter = c1.begin();
    vector<Car*>::iterator iter1 = c2.begin();
        
// make instances of cars on the road
        i = 0;
//        float density = r1[roadNumber]->numberOfCarsOnRoad ; // cars on each road

        //
        
        for (i = 0; i < (number_of_road_nodes-2);) {
            if (RoadArray[i+2]== -1) {
                i=i+3;
                roadNumber++ ;
            } else {
                float length = ++(arVector3(RoadArray[i], GROUND, RoadArray[i+1]) - arVector3(RoadArray[i+2], GROUND, RoadArray[i+3])) ;
                
                // here's a road, add some cars
                numberToMake = int(length / 30) ;

//              numberToMake = 5 ;  // BLAHBLAHBLAH
                
                cout << "make "<< numberToMake << "cars on the length of this road = " << length << endl ;
                for (int mm = 0; mm < numberToMake ; mm++) {
                    Car* tmp = new Car(i, GROUND, true) ;  // for this entire Segment of roads, i starts seg, j ends, there can be any number of nodes in the segment, we create a certain number of cars.
                    c1.push_back(tmp);

                    Car* tmp1 = new Car(i, GROUND, false) ; // go backwards
                    c2.push_back(tmp1);
                }
                
            i = i+2 ;}

        } ; // end while

        cout << "There are " << c1.size() << " cars" << endl ;
                
} ;



// Figure out where the cars should go; this routine will calculate new positions of cars and put them into an array.
void CarAnimate()
{
    totalNumCarsCloseBy = 0 ;
	carsToHear = 0 ; // only make about 20 of these each loop. 

    
    for (int f=0; f< c1.size() ; f++)  {
        if (f < 2000) {
            c1[f]->moveCar(3.0, 0, f)
            ;}
    }

    for (int g=0; g< c2.size() ; g++)  {
        if (g < 2000) {

            c2[g]->moveCarBackwards(3.0, 180, g) ;}
    }
    

      
}

void drawTheCar(arVector3 currentPos, float theAngle, int myCar) {

    float transForm = 3.0 ;
    int isATruck = 0 ;
    float colorR = float((30+(2*myCar)%30)/60.0) ;
    float colorB = float((30+(3*myCar)%30)/60.0) ;
    float colorG = float((30+(5*myCar)%30)/60.0) ;

    if ((myCar%5)==0) {isATruck = 1;} ;
    
    // draw the car
    glPushMatrix();
    glColor3f(colorR, colorG, colorB);  //


    glTranslatef(currentPos[0],currentPos[1],currentPos[2]);


    // only draw the car if it's within 1000 units of your head

    if ((arVector3(currentPos[0],currentPos[1],currentPos[2]) - headPositionInWorld).magnitude() < 1000) {

        totalNumCarsCloseBy++ ;

        glPushMatrix();
        glRotatef(theAngle, 0.0, 1.0, 0.0) ;


        glTranslatef(.3, .6, transForm) ;

        if (isATruck == 1) {
            makeTruck(colorR, colorG, colorB) ;
        } else {
            makeCar(colorR, colorG, colorB) ;
        } ;

        glPopMatrix();

        makeWheels(theAngle, transForm) ;

    } ;

    glPopMatrix();
}    

void carDrawC1(int myCar)
{
//    cout << c1Positions[myCar] << ", " << c1Positions[myCar+1] << ", " << c1Positions[myCar+2] << endl ;
    
	arVector3 currentPos ;
	currentPos[0] = c1Positions[myCar] ;
	currentPos[2] = c1Positions[myCar+1] ;
	currentPos[1] = GROUND ;
	float theAngle = c1Positions[myCar+2] ;

        drawTheCar(currentPos, theAngle, myCar);

}

void carDrawC2(int myCar)
{
//    cout << c2Positions[myCar] << ", " << c2Positions[myCar+1] << ", " << c2Positions[myCar+2] << endl ;

    arVector3 currentPos ;
    currentPos[0] = c2Positions[myCar] ;
    currentPos[2] = c2Positions[myCar+1] ;
    currentPos[1] = GROUND ;
    float theAngle = c2Positions[myCar+2] ;

    drawTheCar(currentPos, theAngle, myCar);
         
}

//*****************************************************

// DO ROADS

// Connect some dots to make roads.

//*****************************************************
void displayLines(void)
{
	int i= 0;
	int roads=0;
	float theta=0.0;
	float slope=0.0;
	float slope1=0.0;
	float myX = 0.0;
	float myY = 0.0;

//        ostringstream myString;

        
	// Draw a line down the center
        glNewList(startList+3, GL_COMPILE) ;

	glColor3f(.7f, .7f, .7f);  // color of line	


        i = 1;
        glBegin( GL_LINE_STRIP );
        while (i < number_of_road_nodes) { 
            if (RoadArray[i-1] != -1) {
            // we're not at the end of a road
                glVertex3f( (RoadArray[i-1]), GROUND, (RoadArray[i]) ); //
//                glVertex3f( (RoadArray[i-1]+6)*30, GROUND, (RoadArray[i]-1)*30 ); //

//                myString << RoadArray[i-1] << " X " << RoadArray[i] << endl; //<< (RoadArray[i]) ;
//                string aString = myString.str() ;
//                myString.str("") ;

//                glPushMatrix() ;
//                letterbox1(aString, RoadArray[i-1], 5, RoadArray[i]) ;
//                glPopMatrix() ;
                
                
                i= i + 2;
            } else {
                // we are at the end of a road
                i++ ;
                glEnd();
                    if (i < number_of_road_nodes) 
//                if (i < myRoadDataVector.size())
                    glBegin( GL_LINE_STRIP );     
//cout << "glBegin( GL_LINE_STRIP )\n" ;

            } ;
                    
//		i++ ;
//		cout << "going to another road\n" ;
                roads++ ;
            } ;
            
	glEnd();
	glFlush();
        
        glEndList();

}


//************* DEBUGGING ROAD INFO

void displayDebugRoads(void)
{
    int i= 0;
    int roads=0;
    float theta=0.0;
    float slope=0.0;
    float slope1=0.0;
    float myX = 0.0;
    float myY = 0.0;

    ostringstream myString;


    // Draw a line down the center
    glNewList(startList+4, GL_COMPILE) ;

    i = 1;

    while (i < number_of_road_nodes) { 
        if (RoadArray[i-1] != -1) {
            // we're not at the end of a road

            myString << RoadArray[i-1] << " X " << RoadArray[i] << endl; //<< (RoadArray[i]) ;
            string aString = myString.str() ;
            myString.str("") ;

            letterbox1(aString, RoadArray[i-1], 5, RoadArray[i]) ;
 
            i= i + 2;
        } else {
            // we are at the end of a road
            i++ ;
            //if (i < number_of_road_nodes) 
        } ;

        roads++ ;
    } ;

    glEndList();

}



//*****************************************************

// Making a Curve - this is not being used right now, just an attempt
// to get started on making curvy roads. 

//*****************************************************
GLfloat ctrlpoints[4][3] = { {-4.0, -4.0, 0.0},  {-2.0, 4.0, 0.0},  {2.0, -4.0, 0.0}, {4.0, 4.0, 0.0}} ;

void initCrv(void)
{glClearColor(0.0, 0.0, 0.0, 0.0);
glShadeModel(GL_FLAT);
glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
glEnable(GL_MAP1_VERTEX_3);
}

void displayCrv(void)
{
int i;
//    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 0, 0);
    glBegin(GL_LINE_STRIP);
        for (i = 0; i<=30; i++)
            glEvalCoord1f((GLfloat) i/30.0);
    glEnd();
    glPointSize(5.0);
    glColor3f(1.0, 1.0, 0.0);
    glBegin(GL_POINTS);
        for (i=0; i<4; i++)
            glVertex3fv(&ctrlpoints[i][0]);
    glEnd();
    glFlush();
}



//*****************************************************

// ********   drawCallback

//*****************************************************

void drawCallback(arMasterSlaveFramework&){


int myRowAdd;
int myColAdd;
static int myCounter = 0 ;
static int timeStepCounter = 0 ;

    arVector3 headPositionInReality = framework->getMatrix(0)*arVector3(0,0,0) ;
//    arVector3 headPositionInWorld = ar_pointToNavCoords(headPositionInReality) ;
    headPositionInWorld = ar_pointToNavCoords(headPositionInReality) ;
    frameTime = framework->getLastFrameTime() ;
//    cout << "frame time = " << frameTime << endl ;


//	This displays our position every 50 frames
	if (myCounter++ >= 50){
		myCounter = 0;
		cout << "position = " << headPositionInWorld << "\n" ;
                
	};
        
        

// Should we make more (or less) cars and toggle between timesteps 1 and 10?
	if (MORETRAFFIC!=0) {
		if (whatDataBasePtr == &array10) {
			cout << "changing back to database1 "<<endl;
			whatDataBasePtr = &array01 ;
			c1.clear();
			c2.clear();
			InstantiateCars() ;

		} else {
          
			whatDataBasePtr = &array10 ;
			cout << "changing to database 10" << endl ;
			InstantiateCars() ;
		}
	MORETRAFFIC=0; 

	}



// Should we advance a timestep??
        if (PLAYTIMESTEPS!=0) {
        
            if (timeStepCounter++ >= 7) {
                timeStepCounter = 0 ;
            // advance a time step
                if (whatDataBasePtr == &array10) {
                whatDataBasePtr = &array01;  } else {
					// ok, well at least I know this will work
					int adder = &array02 - &array01 ;
					whatDataBasePtr += adder ;
//                whatDataBasePtr++ ;
				cout << "array01 = " << &array01 << " array02 = " << &array02 << endl ;
                } ;
                
                cout << "whatdatabase = " << whatDataBasePtr << "\n" ;
            } ;
        } ;
            

 
//	cout << "headPositionInWorld = "<<headPositionInWorld<< " \n";


	myRowAdd = int(headPositionInWorld[2] / zplot) ; // 20 ; 
	myColAdd = int(headPositionInWorld[0] / xplot) ; 

	headX = headPositionInWorld[0];
	headY = headPositionInWorld[1];
	headZ = headPositionInWorld[2];

// draw stuff

	framework -> loadNavMatrix() ;


        static int newX = 0 ;
        static int newY = 0 ;
        static int newZ = 0 ;
            

        arVector3 newxyz(0,0,((newX++)%50));
        arVector3 newxyz1(0,0,((newX++)%50));
        
/*
 glPushMatrix();
//        glTranslatef(float(soundDebugX),50.0f,50.0f);
        glColor3f(.2f,.2f,.7f);
        glTranslatef(0, 0, 5);
        glutSolidCube(10);
*/

        glPopMatrix() ;


        string testWords = "ST LOUIS";
        letterbox(testWords, 50.0f, 3.0f, 50.0f) ; // put this statement at x, y, z

        drawRoutinePtr(myRowAdd, myColAdd) ; // either draw houses or light blocks


        noiseAmp = float(float(totalNumCarsCloseBy) / 100.0) ;
        if (noiseAmp > 1)
        { noiseAmp = 1.0 ;} ;

//        cout << "noiseAmp = " << noiseAmp << endl ;
//        displayCrv() ;
        
}

void makeLightMap(int myRowAdd, int myColAdd)
{
    glPushMatrix();
    makeAFlatGreyPlane();

    glPopMatrix();
//        glCallList(startList+3) ; 	// displayLines() ;
 
    makeMap(myFunctionPtr) ;

}


void mainLandspeederTerrain(int myRowAdd, int myColAdd) 
	{	
        
    if (headY < 800) {
		

		glPushMatrix();
        makeBigGrass(); // this is actually making the flat plane under everything; it's grey now
        makeBigSky();       
	  	glPopMatrix();

        figureOutTextures(); // different textures if night or day
         
        displayWater(tObj) ;		// actually I'm changing the water's colors all the time.
        glCallList(startList) ; 	// water list
        
        glCallList(startList+1) ; 	// displayTessRoads(tObj) ;
        glCallList(startList+2) ; 	// displayPolyRoads() ;
        glCallList(startList+3) ; 	// displayLines() ;
        glCallList(startList+4) ; 	// displayLines() ;

       
        doHouses(myRowAdd, myColAdd); // load in starting at 0, 0  

        
        glPushMatrix();
        

      for (int f=0; f< (c1.size()*3) ; f=f+3)  {
            carDrawC1(f) ;
            carDrawC2(f);
        }
		



	glEnable(GL_BLEND);

//	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	if (timeOfDay == '9') {
//		makeLowCloudCeiling();
		lightDispersement(myRowAdd, myColAdd) ;
		} ;


	doTrees(myRowAdd, myColAdd); // 
	glDisable(GL_BLEND);

	glPopMatrix() ;





    } else {
        
        // make LIGHTMAP (different display than normal landspeeder)
	
	makeMap(myFunctionPtr) ;
	} ;
}

//********************************************************
//
// TESSELATION CALLBACKS
//
//********************************************************


#ifndef CALLBACK
#define CALLBACK
#endif

void CALLBACK errorCallback(GLenum errorCode)

 {
 const GLubyte *estring;
 estring = gluErrorString(errorCode);
 cout << "\nTesselation Error: " << estring << "\n" ;
 exit(0) ;
 }

 //GLvoid beginCallback(GLenum which)
 void CALLBACK beginCallback(GLenum which)
 {
 glBegin(which);
 }


void CALLBACK beginCallbackData(GLenum which, void *polygon_data)
{
 glBegin(which);
}

void CALLBACK vertexCallback(GLvoid *vertex)
{
    const GLdouble *pointer;

    pointer = (GLdouble *) vertex;
    glColor3dv(pointer+3);
    glVertex3dv(pointer);

}

void CALLBACK myCombineData(GLdouble coords[3], 
                              GLdouble *vertex_data[4], 
                              GLfloat weight[4], GLdouble **dataOut )
{
	

	int i;
//	cout << "a" ;
	GLdouble *vertex = new GLdouble[6] ;

//	cout << "b\n" ;

	vertex[0] = coords[0];
	vertex[1] = coords[1];
	vertex[2] = coords[2];

        vertex[3] = 0.0 ;
        vertex[4] = 0.0 ;
       vertex[5] = .50 ;

  *dataOut = vertex;

}


void CALLBACK endCallback(void)
 {
 glEnd();
 }

//***********************************************
//
// TESSELATION CALLBACK REGISTRATION 
// (called in Init)
//
//***********************************************

void registerTessCallbacks() {

// tesselation object callbacks

            tObj = gluNewTess() ;

            gluTessCallback(tObj, GLU_TESS_BEGIN, (void(CALLBACK *)())beginCallback);
            gluTessCallback(tObj, GLU_TESS_BEGIN_DATA, (void(CALLBACK *)())beginCallbackData);
            gluTessCallback(tObj, GLU_TESS_BEGIN, (void(CALLBACK *)())beginCallbackData);
            

//            gluTessCallback(tObj, GLU_TESS_VERTEX, (void(CALLBACK *)())glVertex3dv);  
//            gluTessCallback(tObj, GLU_TESS_COMBINE, (void(CALLBACK *)())myCombine);
                         // or
            gluTessCallback(tObj, GLU_TESS_VERTEX, (void(CALLBACK *)())vertexCallback);
            gluTessCallback(tObj, GLU_TESS_COMBINE, (void(CALLBACK *)())myCombineData);

            gluTessCallback(tObj, GLU_TESS_ERROR, (void(CALLBACK *)())errorCallback);

            gluTessCallback(tObj, GLU_TESS_END, (GLvoid(CALLBACK *)())glEnd);


}


//*************************************************
//       Syzgy Stuff
//*************************************************

//Important variables and arrays to transfer
//to the other workstations

bool init(arMasterSlaveFramework& framework, arSZGClient&){

float startX, startY, startZ ; // for reading in initialization values

    
cout << "\nSTARTING LANDSPEEDER INITIALIZATION" << "\n" ;


glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	dataPath = framework.getDataPath() ;
//    dataPath = dataPath ;

    ar_setNavMatrix(ar_translationMatrix(0,0,6));

// SETUP SHARED DATA HERE!!!

    framework.addTransferField("place", place.v, AR_FLOAT,3);
    framework.addTransferField("whatDataBase", &whatDataBase, AR_CHAR,1);
    framework.addTransferField("whatHouses", &whatHouses, AR_CHAR,1);
    framework.addTransferField("timeOfDay", &timeOfDay, AR_CHAR,1);
    framework.addTransferField("MORETRAFFIC", &MORETRAFFIC, AR_CHAR,1);
    framework.addTransferField("RELOADINIT", &RELOADINIT, AR_CHAR, 1) ;
	framework.addTransferField("PLAYTIMESTEPS", &PLAYTIMESTEPS, AR_CHAR, 1);
    
	framework.addTransferField("c1Positions", &c1Positions[0], AR_FLOAT,6000) ;
	framework.addTransferField("c2Positions", &c2Positions[0], AR_FLOAT,6000) ;

	
	// read initialization file to find out what place to start in

	if ((readInit(startX, startY, startZ)) == 0) {

	ar_navTranslate (arVector3(startX, startY, startZ)) ; 
	cout << "\nstarting at "<<startX<<", "<<startY<<", "<<startZ <<"\n\n" ;

	  
		}else{ 	
		cout << "\nError reading init file, starting at default location.\n" ;
		ar_navTranslate (arVector3(500*xplot, 60, 450*zplot)) ;};

    // do some other init stuff

        readSomeTextures();
        array01 = readFile("database01.txt") ;
        array02 = readFile("database02.txt") ;
        array03 = readFile("database03.txt") ;
        array04 = readFile("database04.txt") ;
        array05 = readFile("database05.txt") ;       
        array06 = readFile("database06.txt") ;
        array07 = readFile("database07.txt") ;
        array08 = readFile("database08.txt") ;     
        array09 = readFile("database09.txt") ;
        array10 = readFile("database10.txt") ;           
                        
        whatDataBasePtr = &array01 ;


        cout << "WhatDataBasePtr = "<< whatDataBasePtr << ", array01 = "<< &array01 << " \n";

        
//		makeRandomArray() ;

		
		readDataFile("roadCenterLines.txt", &RoadArray, number_of_road_nodes) ;
	
		// the third parameter is how high up we want this stuff to display.	
                LakeArray = readTesselFile("waterData.txt", number_of_lake_nodes, -4.0, -5, 1440) ;
		RoadTessArray = readTesselFile("areaAroundRoads.txt", number_of_polyroad_nodes, -4.5, 0, 0) ;


        startList = glGenLists(5) ; // generates some call lists
        
  if (URBANA == 1) {  readHouseDataFile("urbanaHouses.txt") ; }

        makeRandomArray() ;
        figureOutTextures(); // initialize this stuff. 
        
        
        createVectorArray() ; // try to make road database from raster data
        registerTessCallbacks();
        


        myFunctionPtr = makeATile ;
        drawRoutinePtr = mainLandspeederTerrain ;

		displayWater(tObj) ; // this makes a calllist 
                displayPolyRoads() ; // different way of making roads
                
                displayLines() ; // display the centers of roads 

                InstantiateCars() ;

                
                const arVector3 xyz(0,0,0);
                
                transformID = dsTransform("nav", "root", ar_identityMatrix());		
				for (int s=0; s<10; s++){carProximityArray[s]=-1;};
				for (int ss=0; ss<10; ss++){soundArray[ss]=-1;};
				setCarSounds() ;



        return true;
}



//Common syzygy stuff

void preExchange(arMasterSlaveFramework& framework){


// THIS STUFF WILL ONLY HAPPEN ON THE MASTER COMPUTER!


//cout << "lastFrameTime " << framework.getLastFrameTime() << "\n" ;

  if (!framework.getMaster())
    return;

  double timeDelta = framework.getLastFrameTime()/1000.0;

  
  // figure out where the cars are supposed to go.
  CarAnimate() ;


  arMatrix4 wandMatrix = framework.getMatrix(1);

  arVector3 wandDirectionZ = 
    ar_extractRotationMatrix(framework.getMatrix(1)) * arVector3(0,0,-1);
  arVector3 wandDirectionX = 
    ar_extractRotationMatrix(framework.getMatrix(1))* arVector3(1,0,0);
  arVector3 wandDirectionY =
    ar_extractRotationMatrix(framework.getMatrix(1))*arVector3(0,1,0);


  //vary your velocity w.r.t. altitude

  float velocityK ; // = headY*.5 + 30. ; 
  velocityK = (headY * .5) + 20. ;

  // We want to be able to translate in any of three directions relative to the
  // wand and also rotate...
    
  if (framework.getAxis(1) > 0.5){
    wandDirectionZ *= velocityK * timeDelta;
  }
  else if (framework.getAxis(1) < -0.5){
    wandDirectionZ *= -velocityK * timeDelta;
  }
  else{
    wandDirectionZ *= 0.;
  }

  //place += -wandDirection ;
  if (framework.getAxis(2) > 0.5){
    wandDirectionX *= velocityK * timeDelta;
  }
  else if (framework.getAxis(2) < -0.5){
    wandDirectionX *= -velocityK * timeDelta;
  }
  else{
    wandDirectionX *= 0;
  }

  if (framework.getAxis(3) > 0.5){
    wandDirectionY *= velocityK * timeDelta;
  }
  else if (framework.getAxis(3) < -0.5){
    wandDirectionY *= -velocityK * timeDelta;
  }
  else{
    wandDirectionY *= 0;
  }

  ar_navTranslate (wandDirectionX + wandDirectionY + wandDirectionZ) ;

  // We also want to be able to rotate the POV
  if (framework.getAxis(0) > 0.5){
    ar_navRotate(arVector3(0,1,0), -20*timeDelta);
  }  
  else if (framework.getAxis(0) < -0.5){
    ar_navRotate(arVector3(0,1,0), 20*timeDelta);
  }


// Button Stuff
// Get buttons 
    but1 = framework.getButton(0);
    but2 = framework.getButton(1);
    but3 = framework.getButton(2);
    but4 = framework.getButton(3);
    but5 = framework.getButton(4);

    if (but1) {but1wasPressed = 1;
    cout << "BUTTON1" << endl ; } ;
    if (but2) {but2wasPressed = 1;} ;
    if (but3) {but3wasPressed = 1;} ;
    if (but4) {but4wasPressed = 1;} ;
    if (but5) {but5wasPressed = 1;} ;
        
    
// button 1 toggles the daylight / nighttime effect
  if (!but1 & but1wasPressed) {
          if (timeOfDay == '8') {
              // make it nighttime
              timeOfDay = '9';

          } else {
              timeOfDay = '8';
              
          } ;
          cout << "time = " <<  timeOfDay << endl;
          but1wasPressed = 0 ;
  };

  // button 2 starts playing through timesteps
    if (!but2 & but2wasPressed) {
    PLAYTIMESTEPS = !PLAYTIMESTEPS ;
    
    but2wasPressed = 0 ;
  };

  // button 3 toggles "real" textures or cartoony textures
  if (!but3 & but3wasPressed) {
          if (whatHouses == '5') { whatHouses = '6'; } else {whatHouses = '5';} ;
          but3wasPressed = 0 ;
  };

  // button 4 toggles reloading of init.txt file
  if (!but4 & but4wasPressed) {
      RELOADINIT = 1 ;
      but4wasPressed = 0 ;
  };

  // button 5 toggles more / less traffic
  if (!but5 & but5wasPressed)
  {
      cout << "making more cars!"<< endl ;
//      InstantiateCars() ;
      MORETRAFFIC = 1 ;
       
      but5wasPressed = 0 ;
  };
 
  


}

bool postExchange(arMasterSlaveFramework&){

return true;
}


void my_message_callback(arMasterSlaveFramework&, string theData) {

string myFile ;
  cout << "I'm printing the message = " << theData << "\n";

char myMsg = theData[0] ;
 if (myMsg < '4') {
  // here, change databases depending on what number message you get in.
    whatDataBase = myMsg ; // this variable gets set to a string, whatever database number you want to read in. 
	whatDataBasePtr = &array02 ;


 } else if (myMsg < '8') {
    whatHouses = myMsg ;
    } else {
    timeOfDay = myMsg ;
	whatDataBasePtr = &array01 ;
}
}



void playCallback(arMasterSlaveFramework& fw){
   // sound stuff goes here.

	// this will play the highway noise near your head.
//    dsLoop(objectID, "road.mp3", 1, noiseAmp, arVector3(0,0,0)) ;
//    dsLoop(objectID, "road.mp3", 1, 1, arVector3(0,0,0)) ;

calculateCarNoises(c1, &carProximityArray[0], &soundArray[0], &objectIDArray[0]) ;
//cout << "and for c2: "<< endl; 
calculateCarNoises(c2, &carProximityArrayB[0], &soundArrayB[0], &objectIDArrayB[0]) ;
}
	




int main(int argc, char** argv){

        
framework = new arMasterSlaveFramework;
if (!framework->init(argc, argv))
return 1;
framework->setClipPlanes(10,10000);
framework->setInitCallback(init);
framework->setPreExchangeCallback(preExchange);
framework->setPlayCallback(playCallback); // for sound stuff
framework->setDrawCallback(drawCallback);
framework->setPostExchangeCallback(postExchange);
//framework->setUserMessageCallback(my_message_callback);
return framework->start() ? 0 : 1;

}


