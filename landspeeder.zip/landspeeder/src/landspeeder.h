 
/*
 *  landspeeder.h
 *  
 *
 *  Created by rose marshack on Thu Jun 12 2003.
 *  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
 *
 */
/* some terrain stuff */

#define AREA_SIZE  50     /* size of (square) map */
#define F          10.0    /* world scale of one height map cell */
#define PI			3.14159265
#define GROUND -3.8 /* the coordinates of the ground of landspeeder */
#define CEILING 100 /* ceiling for light dispersement */

#include "arTexture.h"


extern arTexture grassTexture ;
extern arTexture asphaltTexture ;

extern arTexture Agus1Texture ;
extern arTexture Agus2Texture ;
extern arTexture Agus3Texture ;

extern arTexture skyTexture ;
extern arTexture skyboxSidesTexture ;
extern arTexture skyboxTopTexture ;
extern arTexture darkSkyboxSidesTexture ;
extern arTexture darkSkyboxTopTexture ;

extern int xplot ; // this is how big each plot of land is
extern int zplot ;

extern float headX; 
extern float headY;
extern float headZ;


#define MAX_ROWS 2100
#define MAX_COLUMNS 2100
#define MAX_DATA_POINTS 8000


/* assume a number will fit into 5 characters on a line */

#define MAX_LINE_SIZE (MAX_COLUMNS * 5)
#define COLUMN_DELIMITER " "
#define ROAD_DELIMITER ","


class Car {
private: 
    float colorR;
    float colorG;
    float colorB;
//    float velocity;
    int beginArrayIndex ; 
    int endArrayIndex ;
    int currentArrayIndex ;
    int objectID ;
//    int isATruck ;

    arVector3 prevNode ;
    arVector3 nextNode ;
    arVector3 beginPos ;
    arVector3 endPos ;
public:
        arVector3 currentPos ;
    
        Car();
    Car(int i, float y, bool m);
    ~Car();
    void moveCar(float zTransform, int angleTransform, int whichCar) ;
    void moveCarBackwards(float zTransform, int angleTransform, int whichCar) ;
} ;


class Road {
private:
public:
    int segmentNumber;
    int numberOfCarsOnRoad;
    vector<Car*> c1;
    Road();
    Road(int i, int j);
    ~Road();
    void makeCarsOnRoad();
};



class RandomPod {
private:
public:
	char jitterX;
	char jitterY; 
	char texture;
	float heightScale;

	RandomPod() ;
	~RandomPod() ;
} ;


class House {
public:
double latitude ;
double longitude ;
int houseType ;
int textureType ;
int roofHeight ;
int x ; int y ; int z ;  // for mesh coordinates

//public:
House();
House(double myLat, double myLong, int myHouseType, int myTexture, int myX, int myY, int myZ, int myRoofHeight);
~House();
void printHouse() ;
void makeUrbanaHouse() ;
} ;

