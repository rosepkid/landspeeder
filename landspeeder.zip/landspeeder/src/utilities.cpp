/*
 *  utilities.cpp
 *  
 *
 *  Created by rose marshack in September 2003.
 *
 */ 
 
#include "arPrecompiled.h"
#include "arDistSceneGraphFramework.h"
#include "stdio.h"
#include "stdlib.h" // just for random number generator



#include "arMasterSlaveFramework.h"
#include "arTexture.h"

#include "math.h"
#include "arMath.h"

// for reading in a file

#pragma warning(disable : 4786) //For VC++ compiler
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>



#include "landspeeder.h"

extern int*** whatDataBasePtr ; 

extern int** array01;
//extern int** array2;
RandomPod** randomArray ;

extern string dataPath; 

char line[MAX_LINE_SIZE + 1];


//extern vector<Road*> r1;

double* RoadArray;  
GLdouble** LakeArray; 
double** RoadTessArray;
double* PolyRoadsArray;


extern int LIGHTMAP ;
extern int CLASSIC ;
extern int URBANA ;

int num_roads;


extern int num_cols;
extern int num_rows;
extern int rows_to_display;
extern int cols_to_display;
extern int number_of_road_nodes ;
extern int number_of_polyroad_nodes ;

// values read in from LEAM output file
extern double smallestX;
extern double smallestY;
extern int NODATA_value ; 
extern int total_num_cols ;
extern int total_num_rows ;

// For Reading In Textures

extern char timeOfDay;

extern void makeLowCloudCeiling();

arTexture grassTexture ; 
arTexture darkGrassTexture ;
arTexture cloudsTexture ;

arTexture asphaltTexture ; 

arTexture houseTexture[7] ;
arTexture darkHouseTexture[7] ;
arTexture urbanaHouseTexture[8];

arTexture Agus1Texture ;
arTexture Agus2Texture ;
arTexture Agus3Texture ;

arTexture skyTexture ;
arTexture skyboxTopTexture ;
arTexture skyboxSidesTexture ;
arTexture darkSkyboxTopTexture ;
arTexture darkSkyboxSidesTexture ;

arTexture darkTreeTexture[4] ;
arTexture treeTexture[4] ;

arTexture bldTexture[4] ;
arTexture darkBldTexture[4] ;

arTexture *myHouseTexture ;
arTexture *myTreeTexture ;
arTexture *myBldTexture ;
arTexture *mySkySide ;
arTexture *mySkyTop ;
arTexture *myGrass ;

arTexture alphaTexture[36];
arTexture numberTexture[10];

/*
// for urbana houses
class House {

public:
double latitude ;
double longitude ;
int houseType ; 
int textureType ;
int roofHeight ;
int x ; int y ; int z ;  // for mesh coordinates

//House();
House(double myLat, double myLong, int myHouseType, int myTexture, int myX, int myY, int myZ, int myRoofHeight);
~House();
void printHouse() ;
} ;
*/

extern vector<House*>  h1 ;

double startLat ; double startLongit ;


//*************************************************
//       Read in an Init file. 
//			(reads in starting location.)
//*************************************************


int readInit(float &x, float &y, float &z) {

	FILE *fpf;
	char *pLine = &(line[0]);
	char *pNum;

	fpf = ar_fileOpen("init.txt", "landspeederData", dataPath,  "rb");
	if (fpf == NULL)
	{
		printf("cannot open file\n");
		return -1;
	} 
	else {
		printf("Init File Opened\n") ;
		
		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);

		sscanf(pLine, "%*s %*s %f %f %f", &x, &y, &z);
//		cout << "x = "<< x << "y = "<< y << "z = "<< z << "\n";

		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);
		sscanf(pLine, "%*s %d", &LIGHTMAP);

		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);
		sscanf(pLine, "%*s %d", &CLASSIC);

		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);
		sscanf(pLine, "%*s %d", &URBANA);

		} 

	fclose(fpf);
	return 0 ;
}


//*************************************************
//       Read in a Tesselation Data file. 
//*************************************************

GLdouble** readTesselFile(string theFile, int &number_of_segments, float myY, int xAdder, int yAdder) {


	FILE *fpf;
	char *pLine = &(line[0]);
	char *pNum;
	int col = 0;
	int row = 0;
    int road=0 ;
	// allocate space for to read in the road file into an array 
	GLdouble** spaceForArray ; 


        
	fpf = ar_fileOpen(theFile, "landspeederData", dataPath, "rb");
	if (fpf == NULL)
	{
		cout << "cannot open file named " << theFile << "\n" ;
//		return -1;
	} 
	else {
		cout << "opened " << theFile ;

// The array needs to be of this type:
// double myArray[][6] ;

	// allocate new space for an array
	spaceForArray = new GLdouble*[MAX_DATA_POINTS] ;
	for (int c = 0; c < MAX_DATA_POINTS; c++) {
		spaceForArray[c] = new GLdouble[6] ;} ;
	  
		if(!spaceForArray) {
			cout << theFile << " - Storage Allocation Failure!!!!\n" ;
		} else { 
			cout << theFile  << " - array storage allocated successfully\n"; 
		} ;	 


//cout << "ok1" ;

		// initialize the array to -1s...
		for (int counter=0; counter<MAX_DATA_POINTS; counter++) {
                    for (int mm=0; mm<6 ; mm++) {
                        spaceForArray[counter][mm] = -1.0; }
                
		}
		
//cout << "ok2" ;

		while (pLine == fgets(pLine, MAX_LINE_SIZE, fpf))
		{

			// initialize strtok() with the current line and get the first number 
			if (col >= (MAX_DATA_POINTS-2)) 
				break;

			pNum = strtok(pLine, ",");

			if ((pNum != NULL) && (*pNum != 'S')) {
				// we're in the middle of inputting road data
                spaceForArray[col][0] = (atof(pNum)+xAdder) ;
                // get the next number from the line 
                pNum = strtok(NULL, ",");
                spaceForArray[col][2] = (atof(pNum)+yAdder) ;
                spaceForArray[col][1] = myY ; 
                
                spaceForArray[col][3] = 0 ;
                spaceForArray[col][4] = 0 ;
                spaceForArray[col][5] = 0 ; //(rand()%100)/100.0 ;
				col++ ;

			} else {
				if (*pNum == 'S') {
					// we found a new road 
					if (col!=0)
					spaceForArray[col++][0] = -1.0 ;
					road++ ;

				} else {
					// we have no more file to read in
					spaceForArray[col++][0] = -1.0 ;
					break ;
				}
			}
		}

		if (col >= (MAX_DATA_POINTS-2)) {
		cout << "More than " << col << " data points in file "<< theFile <<" -- MEMORY LIMIT REACHED.\nSome of your data may not be displayed.\n" ;
		}


	
	fclose(fpf);

	number_of_segments = col ; // global variable so we know how many road nodes we read in

// Print out the file we read in 
    

/*	for (col=0; col < number_of_segments; col++)
                
		{
			if (spaceForArray[col][0] == -1) {
				cout << "end of road \n"; 
				col-- ;
			} else {
				cout << spaceForArray[col][0] << ", " << spaceForArray[col][2] << "\n"; 
			} ;// end if
		} ; // end for
*/
		printf("\n");



		};  
//	cout << "number of polyRoad array nodes = "<<number_of_segments<<"\n";

//	cout << "\n\n" ;
       
	return spaceForArray ;
}



//*************************************************
//       Read in a Data file. (new version)
//*************************************************

int readDataFile(string theFile, double** whatArray, int &number_of_segments) {


	FILE *fpf;
	char *pLine = &(line[0]);
	char *pNum;
	int col = 0;
	int row = 0;
    int road=0 ;
//    vector<Road*>::iterator iter = r1.begin();
    

        
	fpf = ar_fileOpen(theFile, "landspeederData", dataPath, "rb");
	if (fpf == NULL)
	{
		cout << "cannot open file named " << theFile << "\n" ;
		return -1;
	} 
	else {
		cout << "opened " << theFile  ;


		
		// allocate space for to read in the road file into an array 
		
		*whatArray = new double[MAX_DATA_POINTS] ;

		cout << "*whatArray = " << *whatArray << ", RoadArray = "<< RoadArray<<"\n" ;

		// initialize the array to 0s...
		for (int counter=0; counter<MAX_DATA_POINTS; counter++)
        (*whatArray)[counter] = 0.0;


	   if(!(*whatArray)) {
		   cout << theFile << " Storage Allocation Failure!!!!\n" ;
	   } else { cout << " -- storage allocated successfully\n"; }


		
		// read in a line, first line should be "segmentX
//		pLine = fgets(pLine, 100000, fpf);

		while (pLine == fgets(pLine, MAX_LINE_SIZE, fpf))
		{

			// initialize strtok() with the current line and get the first number 
			if (col >= (MAX_DATA_POINTS-2)) 
				break;

			pNum = strtok(pLine, ",");

			if ((pNum != NULL) && (*pNum != 'S')) {
				// we're in the middle of inputting road data
                            (*whatArray)[col++] = ((atof(pNum))+6)*30 ; //  (atof(pNum)) ;
                // get the next number from the line
                            pNum = strtok(NULL, ",");
                (*whatArray)[col++] = ((atof(pNum))-1)*30 ;


			} else {
				if (*pNum == 'S') {
					// we found a new road 
					if (col!=0)
						(*whatArray)[col++] = -1.0 ;
					road++ ;
                                        // added May 13
                                       // pNum = strtok(NULL, ",");
                                       // Road* tmp = new Road(road, atoi(pNum));
                                       // r1.push_back(tmp);                
                                        

				} else {
					// we have no more file to read in
				(*whatArray)[col++] = -1.0 ;
					break ;
				}
			}
		}

		if (col >= (MAX_DATA_POINTS-2)) {
		cout << "More than " << col << " data points in file "<< theFile <<" -- MEMORY LIMIT REACHED.\nSome of your data may not be displayed.\n" ;
		}


	
	fclose(fpf);

	number_of_segments = col ; // global variable so we know how many road nodes we read in

// Print out the file we read in 
/*
	for (col=0; col < number_of_segments; col=col+2)
                
		{
			if ((*whatArray)[col] == -1) {
				cout << "end of road \n"; 
				col-- ;
			} else {
				cout << (*whatArray)[col] << ", " << (*whatArray)[col+1] << "\n"; 
			} ;// end if
		} ; // end for
*/
        
        printf("\n");



        };  
	cout << "number of array nodes = "<<number_of_segments<<"\n";

	cout << "\n\n" ;


        
	return 0 ;
}






//*************************************************
//       Read in a House Data file. (urbana)
//*************************************************
vector<double> myHouseDataVector;

int readHouseDataFile(string theFile) {


	FILE *fpf;
	char *pLine = &(line[0]);
	char *pNum;
	int col = 0;
	int row = 0;
    int road=0 ;
    double myLat; double myLong; int myHouseType; int myTexture; int myX; int myY; int myZ; int myRoofHeight; 
   
   startLat = 0.0 ; 
   startLongit = 0.0 ;

    
//    vector<double>::iterator iter = myHouseDataVector.begin();
    vector<House*>::iterator iter = h1.begin();

	fpf = ar_fileOpen(theFile, "landspeederData", dataPath, "rb");
	if (fpf == NULL)
	{
		cout << "cannot open file named " << theFile << "\n" ;
		return -1;
	} 
	else {
//		cout << "opened " << theFile  ;

//	pLine == fgets(pLine, MAX_LINE_SIZE, fpf) ;
                
		while (pLine == fgets(pLine, MAX_LINE_SIZE, fpf))
//                for (int counter=1; counter<3; counter++)
			{


//                pNum = strtok(pLine, ",");
//                cout << "pLine = "<< pLine << endl ; 
                
                sscanf(pLine, "%lf %lf %d %d %d %d %d %d", &myLat, &myLong, &myHouseType, &myTexture, &myX, &myY, &myZ, &myRoofHeight);

//            cout << "longit = " << myLong << endl ;
//            cout << "lat = " << myLat << endl ;
                
                if (startLat == 0.0) { 
                startLat = myLat ;
                } ;
                
                if (startLongit == 0.0) { 
                startLongit = myLong ;
                } ;
                 
                 cout << "myX " << myX << endl ;
//                cout << "my roof height = " << myRoofHeight << endl ; 


            House* tmp = new House(myLat, myLong, myHouseType, myTexture, myX, myY, myZ, myRoofHeight) ;
            h1.push_back(tmp);

		}
	
	fclose(fpf);

// Print out the file we read in 
    cout << "house size" << h1.size() << endl;
	for (int x = 0; x < h1.size(); x++)           
		{
                cout << "x = " << x <<" latitude = "<< h1[x]->latitude << "\n"; 
                cout << "myTexture = " << h1[x]->textureType << "\n"; 
                
		} ; // end for

		printf("\n");


		};  
       
	return 0 ;
}



//*************************************************
//      Reads a land use (LEAM) data file into a 2-D array.  
//		Returns a pointer to the array.
//*************************************************

int** readFile(string theFile) {

	FILE *fpf;
	char *pLine = &(line[0]);
	char *pNum;
	int col;
	int row = 0;

	int** spaceForArray ; 
//	RandomPod** spaceForRandomArray ;

	// allocate new space for an array
	spaceForArray = new int*[MAX_COLUMNS] ;

	for (int c = 0; c < MAX_ROWS; c++) {
		spaceForArray[c] = new int[MAX_COLUMNS] ;} ;
		
		if (!spaceForArray) {
			cout << theFile << "Storage Allocation Failure!!!!\n" ;
		} else { 
			cout << theFile  << "array storage allocated successfully\n"; 
		} ;	 

	fpf = ar_fileOpen(theFile, "landspeederData",  dataPath, "rb");
	if (fpf == NULL)
	{
		cout << theFile << " could not be opened!!!\n" ;
		return 0;
	} 
	else {
//		cout << theFile << " opened\n" ;

// ignore the first two lines - they have line # data
		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);
		sscanf(pLine, "%*s %i", &total_num_cols);
//		cout << "Total Number of Columns = "<< total_num_cols << "\n" ;

		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);
		sscanf(pLine, "%*s %i", &total_num_rows);
//		cout << "Total Number of Rows = "<< total_num_rows << "\n" ;

		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);

		sscanf(pLine, "%*s %lf", &smallestX);

		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);
		sscanf(pLine, "%*s %lf", &smallestY);


		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);  // cellsize should be 30
		pLine = fgets(pLine, MAX_LINE_SIZE, fpf);
		sscanf(pLine, "%*s %d", &NODATA_value);


		while (pLine == fgets(pLine, MAX_LINE_SIZE, fpf))
		{
			if (num_rows >= MAX_ROWS)
			{
				printf("too many rows (%d max)\n", MAX_ROWS);
				return 0; 
			}
			col = 0;
			// initialize strtok() with the current line and get the first number 
			pNum = strtok(pLine, COLUMN_DELIMITER);
			while (NULL != pNum)
			{ // a number was found in this row 
				if (num_cols >= MAX_COLUMNS)
				{
				printf("too many numbers in row %d (%d max)\n", row, MAX_COLUMNS);
				return 0; 
				}

			// convert the number and put it in the array 


			spaceForArray[col][row] = atoi(pNum);
                        
			col++;
                        
			// keep track of the max number of columns found for later 
			if (col > num_cols)
			{
				num_cols = col;
			}

			// get the next number from the line 
			// pNum is NULL if there aren't any more numbers in the line 
			pNum = strtok(NULL, COLUMN_DELIMITER);
			}

		row++;
		// keep track of the number of rows found for later 
		num_rows = row;
		}

	fclose(fpf);
        
//        cout << "\n" ;


// Print out the file we read in


/*	cout << "number of rows, cols = " << num_rows << ", " << num_cols ;
	for (row=0; row<10; row++)
//	for (row=90; row<150; row++)
	{
		for (col=0; col<10; col++)
//		for (col=90; col<150; col++)
		{
			printf("%4d ", table[col + row*MAX_COLUMNS]);
		}
		printf("\n");
	}
*/

	} ;

	return spaceForArray ;
}




//****************************************************************
// Read A Single Texture (called from readSomeTextures)
//
// if 3rd parameter is false don't blend (make transparent) white
//
//****************************************************************

bool readTexture(arTexture &someTexture_ptr, string theName, bool blendIt = 0)  {

FILE* textureFile ;

  // transparency should pass in 0 (for black in the texture to become
  // transparent). non-transparency should pass in -1.
  int blendParameter = blendIt ? 0 : -1;
  if (!someTexture_ptr.readPPM(theName, "landspeederData", dataPath, blendParameter, true)){
      cout << "BLARG: couldn't open texture file " + dataPath+"/landspeederData/"+theName + "\n";
    return false ;
  }
  return true;
	fclose (textureFile) ;

}




//*************************************************
// Read Some Textures
//*************************************************

void readSomeTextures() {

        readTexture (grassTexture, "grassTexture.ppm");  
        readTexture (darkGrassTexture, "darkGrassTexture.ppm");
        readTexture (cloudsTexture, "cloudsTexture.ppm");  
        
        readTexture (asphaltTexture, "asphaltTexture.ppm");
        
        readTexture (houseTexture[0], "houseTexture1.ppm");
        readTexture (houseTexture[1], "houseTexture2.ppm");
        readTexture (houseTexture[2], "houseTexture3.ppm");
        readTexture (houseTexture[3], "houseTexture4.ppm");
        readTexture (houseTexture[4], "houseTexture5.ppm");
        readTexture (houseTexture[5], "houseTexture6.ppm");
        readTexture (houseTexture[6], "houseTexture7.ppm");
        
        readTexture (Agus1Texture, "Agus1Texture.ppm");
        readTexture (Agus2Texture, "Agus2Texture.ppm");
        readTexture (Agus3Texture, "Agus3Texture.ppm");
        readTexture (bldTexture[0], "bldTexture1.ppm");
        readTexture (bldTexture[1], "bldTexture2.ppm");
        readTexture (bldTexture[2], "bldTexture3.ppm");
        readTexture (bldTexture[3], "bldTexture4.ppm");

        readTexture (darkBldTexture[0], "darkBldTexture1.ppm");
        readTexture (darkBldTexture[1], "darkBldTexture2.ppm");
        readTexture (darkBldTexture[2], "darkBldTexture3.ppm");
        readTexture (darkBldTexture[3], "darkBldTexture4.ppm");

        readTexture (skyTexture, "skyTexture.ppm");
        readTexture (skyboxTopTexture, "skyboxTopTexture.ppm");
        readTexture (skyboxSidesTexture, "skyboxSidesTexture.ppm");
        readTexture (darkSkyboxTopTexture, "darkSkyboxTop.ppm");
        readTexture (darkSkyboxSidesTexture, "darkSkyboxSides.ppm");

        readTexture (treeTexture[0], "treeTexture1.ppm", 1); // 1 will make transparency of anything white
        readTexture (treeTexture[1], "treeTexture2.ppm", 1);
        readTexture (treeTexture[2], "treeTexture3.ppm", 1);
        readTexture (treeTexture[3], "treeTexture4.ppm", 1);
 

//        readTexture (darkTreeTexture[0], "darkTreeTexture1.ppm", 1); // 1 will make transparency of anything white
//        readTexture (darkTreeTexture[1], "darkTreeTexture2.ppm", 1);
//        readTexture (darkTreeTexture[2], "darkTreeTexture3.ppm", 1);
//        readTexture (darkTreeTexture[3], "darkTreeTexture4.ppm", 1);               

        
        readTexture (darkHouseTexture[0], "darkHouseTexture1.ppm");
        readTexture (darkHouseTexture[1], "darkHouseTexture2.ppm");
        readTexture (darkHouseTexture[2], "darkHouseTexture3.ppm");
        readTexture (darkHouseTexture[3], "darkHouseTexture4.ppm");
        readTexture (darkHouseTexture[4], "darkHouseTexture5.ppm");
        readTexture (darkHouseTexture[5], "darkHouseTexture6.ppm");
        readTexture (darkHouseTexture[6], "darkHouseTexture7.ppm");

        readTexture (urbanaHouseTexture[0], "urbana.808.Iowa.ppm");
        readTexture (urbanaHouseTexture[1], "urbana.716.Iowa.ppm");
       readTexture (urbanaHouseTexture[2], "urbana.806.Iowa.ppm");
         readTexture (urbanaHouseTexture[3], "urbana.DF-10.Busey.ppm");
         readTexture (urbanaHouseTexture[4], "urbana.DF-8.Busey.ppm");
         readTexture (urbanaHouseTexture[5], "urbana.DF-9.Busey.ppm");
        readTexture (urbanaHouseTexture[6], "urbana.810.Iowa.ppm");
        readTexture (urbanaHouseTexture[7], "urbana.1002.Busey.ppm");


       readTexture (alphaTexture[0], "A.ppm", 1);
        readTexture (alphaTexture[1], "B.ppm", 1);
        readTexture (alphaTexture[2], "C.ppm", 1);
        readTexture (alphaTexture[3], "D.ppm", 1);
        readTexture (alphaTexture[4], "E.ppm", 1);
        readTexture (alphaTexture[5], "F.ppm", 1);
        readTexture (alphaTexture[6], "G.ppm", 1);
        readTexture (alphaTexture[7], "H.ppm", 1);
        readTexture (alphaTexture[8], "I.ppm", 1);
        readTexture (alphaTexture[9], "J.ppm", 1);
        readTexture (alphaTexture[10], "K.ppm", 1);
        readTexture (alphaTexture[11], "L.ppm", 1);
        readTexture (alphaTexture[12], "M.ppm", 1);
        readTexture (alphaTexture[13], "N.ppm", 1);
        readTexture (alphaTexture[14], "O.ppm", 1);
        readTexture (alphaTexture[15], "P.ppm", 1);
        readTexture (alphaTexture[16], "Q.ppm", 1);
        readTexture (alphaTexture[17], "R.ppm", 1);
        readTexture (alphaTexture[18], "S.ppm", 1);
        readTexture (alphaTexture[19], "T.ppm", 1);
        readTexture (alphaTexture[20], "U.ppm", 1);
        readTexture (alphaTexture[21], "V.ppm", 1);
        readTexture (alphaTexture[22], "W.ppm", 1);
        readTexture (alphaTexture[23], "X.ppm", 1);
        readTexture (alphaTexture[24], "Y.ppm", 1);
        readTexture (alphaTexture[25], "Z.ppm", 1);
        readTexture (alphaTexture[26], "0.ppm", 1);
        readTexture (alphaTexture[27], "1.ppm", 1);
        readTexture (alphaTexture[28], "2.ppm", 1);
        readTexture (alphaTexture[29], "3.ppm", 1);
        readTexture (alphaTexture[30], "4.ppm", 1);
        readTexture (alphaTexture[31], "5.ppm", 1);
        readTexture (alphaTexture[32], "6.ppm", 1);
        readTexture (alphaTexture[33], "7.ppm", 1);
        readTexture (alphaTexture[34], "8.ppm", 1);
        readTexture (alphaTexture[35], "9.ppm", 1);

        readTexture(numberTexture[0], "0.ppm", 1) ;
        readTexture(numberTexture[1], "1.ppm", 1) ;
        readTexture(numberTexture[2], "2.ppm", 1) ;
        readTexture(numberTexture[3], "3.ppm", 1) ;
        readTexture(numberTexture[4], "4.ppm", 1) ;
        readTexture(numberTexture[5], "5.ppm", 1) ;
        readTexture(numberTexture[6], "6.ppm", 1) ;
        readTexture(numberTexture[7], "7.ppm", 1) ;
        readTexture(numberTexture[8], "8.ppm", 1) ;
        readTexture(numberTexture[9], "9.ppm", 1) ;
        

}


void figureOutTextures()
{
    myTreeTexture = &treeTexture[0] ;

    
    if (timeOfDay == '8') {

        myHouseTexture = &houseTexture[0] ;
        myBldTexture = &bldTexture[0] ;
        mySkyTop = &skyboxTopTexture ;
        mySkySide = &skyboxSidesTexture ;
        myGrass = &grassTexture ;
        
    } else {

        myHouseTexture = &darkHouseTexture[0] ;
        myBldTexture = &darkBldTexture[0] ;
        mySkyTop = &darkSkyboxTopTexture ;
        mySkySide = &darkSkyboxSidesTexture ; 
        myGrass = &darkGrassTexture ;


         
    } ;

}


//************************************************

// Initialize Lighting

//************************************************

void initLighting() 
{
		GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 } ;
		GLfloat mat_shininess[] = { 50.0 } ;
		GLfloat light_position[] = { 1.0, 1.0, 1.0, 1.0 } ;
		GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 } ;
		GLfloat lmodel_ambient[] = { 0.1, 1.0, 1.0, 1.0 } ;
		glClearColor(0.0, 0.0, 0.0, 0.0) ;
		glShadeModel(GL_SMOOTH);

		glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
		glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
		glLightfv(GL_LIGHT0, GL_SPECULAR, white_light) ;
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);

		glEnable(GL_LIGHTING) ;
		glEnable(GL_LIGHT0);
		glEnable(GL_DEPTH_TEST) ;
}
//************************************************

// make random array

//************************************************

void makeRandomArray() {
	
		srand ( 71473375 );  // (415 pages in plowing the dark, by richard powers) ^ 3



		randomArray = new RandomPod*[MAX_COLUMNS] ;
		for (int c = 0; c < MAX_ROWS; c++) {
//		randomArray[c] = new char[MAX_COLUMNS] ;
		randomArray[c] = new RandomPod[MAX_COLUMNS] ;
	   }

	   if(!randomArray) {
		   cout << "n\n\nrandomArray Storage Allocation Failure!!!!\n\n\n" ;
	   } else { cout << "\nrandomArray storage allocated successfully\n"; }

//	for (int j=0; j<MAX_ROWS; j++) {
//		for (int i=0; i<MAX_COLUMNS; i++) {
//			randomArray[i][j] = rand()%46 ;  // 46 chapters in plowing the dark
	//		cout << "randomArray jitter X" << i << "< " << j << " is " << randomArray[i][j].jitterX << endl ;
//		}
//	}

/*	for (int row=0; row<MAX_ROWS; row++)
	{
		for (int col=0; col<MAX_COLUMNS; col++)
		{
			printf("%4d, ", randomArray[col][row]);
		}
		printf("\n");
	}
*/
	cout << "\n\n" ;
} ;

int arrayTest[6][5] = {
{24, 0, 24, 0, 0},
{0, 24, 24, 0, 0},
{0, 0, 24, 0, 0},
{0, 0, 24, 0, 0},
{0, 0, 24, 24, 24},
{0, 0, 24, 0, 0}};

//cellData = (*whatDataBasePtr)[i][j];

char arrayFlags[MAX_ROWS][MAX_COLUMNS] ;

 // NW, NN, NE, W, E, SW, S, SE
 
 // allocate space for road data - middle line - for cars
vector<int> myRoadDataVector;
void addToVector(int x, int y) {
        myRoadDataVector.push_back(30*x);
        myRoadDataVector.push_back(30*y);
} ;

void checkNeighbor (int x, int y, int prevX, int prevY) {
// first coord is how far down; 2nd is across
// cout << "check neighbor "<< x <<", "<<y<<"with previous "<<prevX<<", "<<prevY << endl ;
    if ((*whatDataBasePtr)[x][y]==24) {
       
    // check for a neighbor.
        if (((*whatDataBasePtr)[x][y+1] == 24) && ((prevX==x) && (prevY==y-1))) {
        // found a neighbor. did we already traverse this path? (E path)
           if (!(arrayFlags[x][y] & 0x08)) {
                arrayFlags[x][y] |= 0x08 ; 
//                cout << "(" << x << ", " << y << ")" << endl ;
                checkNeighbor (x, y+1, x, y) ;
                } ;
        } else
        if (((*whatDataBasePtr)[x+1][y-1] == 24) && ((prevX==x-1) && (prevY==y+1))) {
            if (!(arrayFlags[x][y] & 0x04)) {
                arrayFlags[x][y] |= 0x04 ; 
//                cout << "(" << x << ", " << y << ")" << endl ;
                checkNeighbor (x+1, y-1, x, y) ;
            }

         } else
         if (((*whatDataBasePtr)[x+1][y] == 24) && ((prevX==x-1) && (prevY==y))) {
            if (!(arrayFlags[x][y] & 0x02)) {
                arrayFlags[x][y] |= 0x02 ; 
 //               cout << "(" << x << ", " << y << ")" << endl ;
                checkNeighbor (x+1, y, x, y) ;
            }

        } else
        if (((*whatDataBasePtr)[x+1][y+1] == 24) && ((prevX==x-1) && (prevY==y-1))) {
            if (!(arrayFlags[x][y] & 0x01)) {
                arrayFlags[x][y] |= 0x01 ; 
  //              cout << "(" << x << ", " << y << ")" << endl ;
                checkNeighbor (x+1, y+1, x, y) ;
            }
          } else {
        
       // if we got here, there are no neighbors that have 24s, so we have a node
//        cout << "endpoint: ("  << x << ", " << y << ")\n" ; 
//        cout << "vector size = " << myRoadDataVector.size() << endl;
        // here we want to make sure there are no 1-node adjacent nodes.
        int dx = myRoadDataVector.at (myRoadDataVector.size()-2) - x;
        int dy = myRoadDataVector.at (myRoadDataVector.size()-1) - y ;
//        cout << "dx, dy = "<< dx<<", "<<dy<<endl ;
        if ((abs(dx) > 1) || (abs(dy) > 1)) {
//        if (myRoadDataVector.at(myRoadDataVector.size()-2)!=-1) {
        addToVector(x, y) ;
        myRoadDataVector.push_back(-1); // put an end segment on the vector!
//        myRoadDataVector.push_back(-1); // put an end segment on the vector!
        } else {
        myRoadDataVector.pop_back() ;
        myRoadDataVector.pop_back() ;
        } ;
       } ;
    // if previous neighbor is in line with next neighbor, we just call again on next neighbor.
    // if previous neighbor isn't in line with next neighbor we store node and call on next neighbor.
 };
};



void checkNeighbor (int x, int y) {  // called from the top of a road

//cout << "beginning: "<< x <<", "<<y<<endl ;
    if ((*whatDataBasePtr)[x][y]==24) {
    // check for a neighbor.
        if ((*whatDataBasePtr)[x][y+1] == 24) {
        
            if (!(arrayFlags[x][y] & 0x08)) {
                arrayFlags[x][y] |= 0x08 ; 

//                cout << "(" << x << ", " << y << ")" << endl ;
                addToVector(x, y) ;
                checkNeighbor (x, y+1, x, y) ;
                }
        } 
        if ((*whatDataBasePtr)[x+1][y-1] == 24) {
            if (!(arrayFlags[x][y] & 0x04)) {
                arrayFlags[x][y] |= 0x04 ; 
//                cout << "(" << x << ", " << y << ")" << endl ;
                addToVector(x, y) ;
                checkNeighbor (x+1, y-1, x, y) ;
         }
         } 
         if ((*whatDataBasePtr)[x+1][y] == 24) {
            if (!(arrayFlags[x][y] & 0x02)) {
                arrayFlags[x][y] |= 0x02 ; 
                addToVector(x, y) ;
//                cout << "(" << x << ", " << y << ")" << endl ;
                checkNeighbor (x+1, y, x, y) ;
         }
        } 
        if ((*whatDataBasePtr)[x+1][y+1] == 24) {
                    if (!(arrayFlags[x][y] & 0x01)) {
                    arrayFlags[x][y] |= 0x01 ; 
                    addToVector(x, y) ;
//                    cout << "(" << x << ", " << y << ")" << endl ;
                    checkNeighbor (x+1, y+1, x, y) ;
         }
          }
          
//            else {
        
       // if we got here, there are no neighbors that have 24s, so we have a node
//       cout << "shouldn't get here; this is a very lonely 24 endpoint: ("  << x << ", " << y << ")\n" ; 
//       } ;
    // if previous neighbor is in line with next neighbor, we just call again on next neighbor.
    // if previous neighbor isn't in line with next neighbor we store node and call on next neighbor.
 };
};


void createVectorArray()
 {
 
 // init array flags
 for (int row=0; row<total_num_rows; row++) {
    for (int col=0; col<total_num_cols; col++) {
        arrayFlags[row][col] = 0;
    }
}
     vector<int>::iterator iter = myRoadDataVector.begin();

    for (int x = 0; x < total_num_rows; x++) {
        for (int y =  0; y < total_num_cols ; y++) {
//        cout << "Checking " << x <<", "<<y << endl ;
            checkNeighbor(x, y) ; 
            } ; // end for
    } ; // end for
    
//    cout << "myRoadDataVector = "<< myRoadDataVector << endl ;
       cout << "size = " << myRoadDataVector.size() << endl ;
//

// trim all "L"s 
//    for (int f=0; f< myRoadDataVector.size() ; f++)  {
    
//}


    for (int f=0; f< myRoadDataVector.size() ; f++)  {
//        cout << myRoadDataVector[f] << ", " ;
        f++ ;
//        cout << myRoadDataVector[f] << endl ;
    }

}


