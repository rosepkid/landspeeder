/***********************************************************/
//
//     SOUND.CPP for landspeeder
//
/***********************************************************/

#include "arPrecompiled.h"
#include "arDistSceneGraphFramework.h"
#include "stdio.h"
#include "stdlib.h" // just for random number generator

#include "arMasterSlaveFramework.h"


#include "math.h"
#include "arMath.h"
#include "arSoundAPI.h"

#include "landspeeder.h"

#include <sstream>

#pragma warning(disable : 4786) //For VC++ compiler
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>


void calculateCarNoises(vector<Car*> c, int* arg, int* arg1, int* objectIDArray) ;


extern vector<Car*> c1;
extern vector<Car*> c2;
extern arVector3 headPositionInWorld ;

extern int objectIDArray[10] ;
extern int objectIDArrayB[10] ;



void setCarSounds() {

	stringstream aCarNoise ;
	const arVector3 xyz(-500,-500,-500);

	for (int n=0; n<10; n++) {
	
		aCarNoise << "carNoise" << n << endl ;	
		objectIDArray[n] = dsLoop(aCarNoise.str(), "nav", "car.mp3", 1, 1, xyz) ; 

		aCarNoise << "B" << endl;	

		objectIDArrayB[n] = dsLoop(aCarNoise.str(), "nav", "car.mp3", 1, 1, xyz) ;  // other side of street                             
		aCarNoise.flush() ;

	}

}

int checkForSmallest(int myCar, float aMagnitude, int* AcarProximityArray) {
//	cout << "this magnitude is " << aMagnitude << endl ; 
	int keep = -1 ;
	bool foundAMatch = false ;

	// first make sure the car isn't already in the array,
	for (int i=0; i<10; i++) {
		if (AcarProximityArray[i] == myCar) {foundAMatch = true;} ;
	} ;

	if (!(foundAMatch)) {

		for (int i=0; i<10; i++) {

			if ((AcarProximityArray[i] < 0) || (AcarProximityArray[i] > c1.size())) {
				keep = i ;
				break ;
			} else {

				if (aMagnitude < ((c1[AcarProximityArray[i]]->currentPos) - headPositionInWorld).magnitude()) {
					keep = i ;
					break ;
				} ;
			}

		} ; 
	}
	 
return (keep) ;
} ;

void addThisCarToArray(int thisCar, int* AcarProximityArray, int* AsoundArray) {
//	stringstream myCarNoise ;
	// go through soundArray, if you find a -1, put this car into it.
	for (int r=0; r< 10;r++) {
		if (AsoundArray[r]==-1) {
			AsoundArray[r]=AcarProximityArray[thisCar] ;

//			myCarNoise << "carNoise" << r << endl;
//			cout << "adding "<< myCarNoise.str() << " to the sound matrix " << endl ;
//			arVector3 xyz = c1[carProximityArray[thisCar]]->currentPos ;
//			objectIDArray[r] = dsLoop(myCarNoise.str(), "nav", "car.mp3", 1, 1, xyz) ;                               
			break;
		}; 
	} ;

} ;

void makeSureNoDuplicates(int thisSound, int* AsoundArray) {
	// go through soundArray, if you find a duplicate, put -1 in it
	int matchingNumber = AsoundArray[thisSound] ;
	for (int r=thisSound+1; r< 10;r++) {
		if (AsoundArray[r]==matchingNumber) {
			AsoundArray[r]=-1 ;
		}; 
	} ;

}


void calculateCarNoises(vector<Car*> c1, int* AcarProximityArray, int* AsoundArray, int* AnObjectIDArray) {	
	for (int f=0; f< c1.size() ; f++)  {
		// determine which are the nearest 10 cars.
		int myNumber = checkForSmallest(f, ((c1[f]->currentPos) - headPositionInWorld).magnitude(), AcarProximityArray) ;
		if ( myNumber > -1) {
			AcarProximityArray[myNumber] = f ;

		}

	}
/*	cout << "nearest cars are " ;
	for (int iii=0; iii<10; iii++) {
		cout << AcarProximityArray[iii] << " ";
		} ;
	cout << endl ; 
*/ 
	// now that I have the nearest 10 cars, look at my sounds, 
	// if one of the sounds isn't in the 10 nearest car array, then 
	// associate it with a new sound. woohoo!
/*
	cout << "sounds are " ;
	for (int iij=0; iij<10; iij++) {
		cout << AsoundArray[iij] << " ";
		} ;
	cout << endl ; 
*/
	// go through sound array. If you find a car in here that is not in the car array, 
	// then throw it out.
	for (int thisSound=0; thisSound<10; thisSound++) {
		bool foundMatch = false ;
		for (int thisCar=0; thisCar<10; thisCar++) {
			if (AsoundArray[thisSound] == AcarProximityArray[thisCar]) { 
				foundMatch = true ;
				makeSureNoDuplicates(thisSound, AsoundArray) ;
				break ;
			} ;
			
		} ;
		if (!(foundMatch)) { 
			AsoundArray[thisSound] = -1 ;
		} ;

	} ;
/*	cout << "after checking sound array, sounds are " ;
	for (int ii=0; ii<10; ii++) {
		cout << AsoundArray[ii] << " ";
		} ;
	cout << endl ; 
*/

	// go through carArray now, if don't find a match in SoundArray, put it in a -1 spot
	for (int thisCar=0; thisCar<10; thisCar++) {
		bool foundMatch = false ;
		for (int tthisSound=0; tthisSound<10; tthisSound++) {
			if (AsoundArray[tthisSound]==AcarProximityArray[thisCar]) {
				foundMatch = true ;
				break ;
			}
		}
		if (!(foundMatch)) {
			addThisCarToArray(thisCar, AcarProximityArray, AsoundArray) ;
		} ;

			
	};
	
//	cout << "DONE: sound cars are " ;
	stringstream myCarNoise ;

	for (int i=0; i<10; i++) {
//		cout << soundArray[i] << " ";
		myCarNoise.flush() ;

		myCarNoise << "carNoise" << i << endl;

		if (AcarProximityArray[i]>=0) {

			arVector3 xyz = ar_pointFromNavCoords(c1[AcarProximityArray[i]]->currentPos) ;
			dsLoop(AnObjectIDArray[i], "car.mp3", 1, 1, xyz) ;

		} ;

		} ;
//	cout << endl ; 
//	cout << "\n\n\n" ;
}